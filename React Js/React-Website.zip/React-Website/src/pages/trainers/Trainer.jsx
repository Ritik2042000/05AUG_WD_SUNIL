import React from 'react';
import  './trainer.css';

const Trainer = () => {
    return (
        <div>
            welocon to trainer
        </div>
    );
};

export default Trainer;