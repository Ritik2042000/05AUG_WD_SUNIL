import { configureStore } from '@reduxjs/toolkit'
import loginSlice from './login_user/loginUserSlice'

export const store = configureStore({
    reducer: {
        userData: loginSlice
    },
})