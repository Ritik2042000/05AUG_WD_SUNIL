import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    userData: {
        type: JSON.parse(localStorage.getItem("type")) || "",
        token: JSON.parse(localStorage.getItem("token")) || "",
        labels: {
            englishLabels: JSON.parse(localStorage.getItem("EnglishLabels" || [])) || [],
            arabicLabels: JSON.parse(localStorage.getItem("ArabicLabels" || [])) || [],
        }
    }
}

export const loginSlice = createSlice({
    name: 'login',
    initialState,
    reducers: {
        setUserLogin: (state, action) => {
            state.userData = action.payload
        },
    },
})
export const { setUserLogin } = loginSlice.actions

export default loginSlice.reducer