import { Navigate, Outlet } from "react-router-dom";
import Login from "../components/Pages/Login";
import Dashboard from "../components/Pages/Dashboard";

import Notification from "../components/Pages/Notification";
import BusinessAdminLayout from "../components/CommonLayouts/BusinessAdminLayout";
import AuthLogin from "../components/Pages/AuthLogin";
import IndividualSidebar from "../components/CommonLayouts/IndividualSidebar";
import "../assets/css/App.css"
import MemberShipTransaction from "../components/Pages/Reports/MembershipTransaction";
import ExportContractList from "../components/Pages/Reports/ExportContractList";
import ExportContactList from "../components/Pages/Reports/ExportContactList";
import ContractFinancial from "../components/Pages/Reports/ContractFinancial";
import ContractUtilization from "../components/Pages/Reports/ContractUtilization";
import Contract from "../components/Pages/Contract";
import CreateContract from "../components/Pages/CreateContract.jsx";
import AddressBook from "../components/Pages/AddressBook/AddressBook.jsx";
import Profile from "../components/Pages/Profile/Profile.jsx";

const routes = (user) => {

    const BusinessLayout = () => {
        return <>
            <BusinessAdminLayout />
        </>
    }

    const IndividualLayout = () => {

        return <>
            <IndividualSidebar />
            <Outlet />
        </>
    }

    return [
        {
            path: "/",
            element: !user.type ? <Navigate to={"/login"} /> : <Navigate to={"/dashboard"} />
        },
        {
            path: "/login",
            element: !user.type ? <Login /> : <Navigate to={"/"} />
        },
        {
            path: "/authLogin/:token/:type",
            element: !user.type ? <AuthLogin /> : <Navigate to={"/"} />
        },
        user?.type == "business" &&
        {
            path: "/",
            element: user.type == 'business' ? <BusinessLayout /> : <Navigate to={"/login"} />,
            children: [
                {
                    path: "/dashboard",
                    element: <Dashboard />
                },
                {
                    path: "/profile",
                    element: <Profile/>
                },
                {
                    path: "/notification",
                    element: <Notification />
                },
                {
                    path: "/contaracthistory",
                    element: <ContractUtilization/>
                },
                {
                    path: "/contaractransaction",
                    element: <ContractFinancial />
                },
                {
                    path: "/membershiptransaction",
                    element: <MemberShipTransaction />
                },
                {
                    path: "/exportcontractlist",
                    element: <ExportContractList />
                },
                {
                    path: "/exportcontactlist",
                    element: <ExportContactList />
                },
                {
                    path:"/contract",
                    element:<Contract/>
                },
                {
                    path:"/address_book",
                    element:<AddressBook/>
                },
               
                {
                    path:"/contracr_template",
                    element:<CreateContract/>
                },
               
            ]
        },

        user?.type == "individual" &&
        {
            path: "/",
            element: user.type == 'individual' ? <IndividualLayout /> : <Navigate to={"/login"} />,
            children: [
                {
                    path: "/dashboard",
                    element: <Dashboard />
                }
            ]
        },



    ]
}

export default routes;