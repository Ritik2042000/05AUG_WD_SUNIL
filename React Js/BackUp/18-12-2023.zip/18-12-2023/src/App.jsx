import { BrowserRouter, useRoutes } from 'react-router-dom';
import routes from './routes/routes';
import { useSelector } from 'react-redux';

function App() {
  const { userData } = useSelector((state) => state?.userData)

  const route = useRoutes(routes(userData));
  return <>{route}</>;
}

const AppWrapper = () => {
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
};

export default AppWrapper;
