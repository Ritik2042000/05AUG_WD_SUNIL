import React from 'react';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Popper from '@mui/material/Popper';

// import Grid from '@mui/material/Grid';
// import Button from '@mui/material/Button';
import Fade from '@mui/material/Fade';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Popover from '@mui/material/Popover';
import Contract from '../Pages/Contract';

const PopoverComponent = () => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [open, setOpen] = React.useState(false);
    const [placement, setPlacement] = React.useState();

    const handleClick = (newPlacement) => (event) => {
        setAnchorEl(event.currentTarget);
        setOpen((prev) => placement !== newPlacement || !prev);
        setPlacement(newPlacement);
    };
    return (
        <>
            <Box sx={{ width: 500 }}>
                <Popper
                    // Note: The following zIndex style is specifically for documentation purposes and may not be necessary in your application.
                    sx={{ zIndex: 1200 }}
                    open={open}
                    anchorEl={anchorEl}
                    placement={placement}
                    transition
                >
                    {({ TransitionProps }) => (
                        <Fade {...TransitionProps} timeout={35}>
                            <Paper>
                                <Typography sx={{ p: 2 }}>
                                    <div>
                                        The content of the Popper.
                                    </div>

                                </Typography>
                            </Paper>
                        </Fade>
                    )}
                </Popper>
                <Button onClick={handleClick('left-end')}>left-end</Button>
            </Box>
        </>
    );
};

export default PopoverComponent;