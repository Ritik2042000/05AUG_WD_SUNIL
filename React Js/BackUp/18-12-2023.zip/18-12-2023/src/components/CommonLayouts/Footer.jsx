import React from 'react';

const Footer = () => {
  return (
    <div>
      <div className="footer py-4 d-flex flex-lg-column app-footer mt-10 position-fixed bottom-0 end-0 w-100">
        <div className="app-container container-fluid  d-flex flex-column flex-md-row flex-center flex-md-stack py-3 justify-content-end">
          <div className="text-dark order-2 order-md-1 me-15">
            <span className="text-gray-800 fw-bold me-1">© 2023</span>
            <a
              className="text-gray-800 text-hover-primary"
              href="/business-admin/profile#."
              target="_blank"
            >
              tothiq.com
            </a>
          </div>
        </div>
      </div>

    </div>
  )
}

export default Footer