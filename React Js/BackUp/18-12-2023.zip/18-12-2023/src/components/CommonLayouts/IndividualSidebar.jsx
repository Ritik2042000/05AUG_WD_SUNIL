import { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

const IndividualSidebar = () => {
    const navigate = useNavigate()
    const location = useLocation()

    useEffect(() => {
        if (location.pathname == "/") {
            navigate('/dashboard')
        }
    }, [])
    return (
        <div>IndividualSidebar</div>
    )
}

export default IndividualSidebar