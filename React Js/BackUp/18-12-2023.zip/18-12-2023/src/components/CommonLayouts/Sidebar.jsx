import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import Logo from "../../assets/images/logo.png";
import sidebar_footer_logo from "../../assets/images/sidebar-footer-logo.png";

const Sidebar = () => {
  const [rotateAngle, setRotateAngle] = useState(0);

  // dropDown state
  const [height, setHeight] = useState("drop-down");

  // dropDowns menu functions
  // const toggleDropdown = (height, setStateFunction) => {
  //   setStateFunction((prevState) =>
  //     prevState === "drop-down" ? "drop-down_open" : "drop-down"
  //   );
  // };

  // const toggleDropdown = (newHeight) => {
  //   setHeight((prevHeight) => (prevHeight === newHeight ? 'drop-down' : newHeight));
  // };

  console.log(height);
  // const closeAllDropdowns = () => {
  //   setHeight("drop-down");
  //   setSidebarOpen(false);
  // };

  const dropdown = (height, setStatefunction) => {
    if (height === 'drop-down') {
        setStatefunction((height) => (height = 'drop-down_open'))
    } else {
        setStatefunction((height) => (height = 'drop-down'))
    }
};

const handleDropdownClick = (event) => {
  // Prevent the event from propagating to the parent element
  event.stopPropagation();
};

  // rotate Fuctions
  const handleRotate = () => {
    setRotateAngle((prevAngle) => (prevAngle === 0 ? 180 : 0));
  };

  const [asideMinimize, setAsideMinimize] = useState(false);

  const toggleAsideMinimize = () => {
    const newMinimizeState = !asideMinimize;
    setAsideMinimize(newMinimizeState);
    const bodyMinimizeState = newMinimizeState ? "on" : "off";
    document.body.setAttribute("data-kt-aside-minimize", bodyMinimizeState);
    const asideElement = document.getElementById("kt_aside");
    if (newMinimizeState) {
      asideElement.classList.add("animating");
    }
    setTimeout(() => {
      asideElement.classList.remove("animating");
    }, 1000);
  };

  const logoutFunction = () => {
    localStorage.clear();
  };

  return (
    <div onClick={handleDropdownClick}>
      <div
        id="kt_aside"
        className="aside aside-light aside-hoverable"
        data-kt-drawer="true"
        data-kt-drawer-name="aside"
        data-kt-drawer-activate="{default: true, lg: false}"
        data-kt-drawer-overlay="true"
        data-kt-drawer-width="{default:'200px', '300px': '250px'}"
        data-kt-drawer-direction="start"
        data-kt-drawer-toggle="#kt_aside_mobile_toggle"
      >
        <div className="aside-logo flex-column-auto h-125px" id="kt_aside_logo">
          <NavLink to="../../demo1/dist/index.html">
            <img alt="Logo" src={Logo} className="logo" />
          </NavLink>
          <div
            id="kt_aside_toggle"
            className="btn btn-icon w-auto px-0 btn-active-color-primary aside-toggle"
            data-kt-toggle="true"
            data-kt-toggle-state="active"
            data-kt-toggle-target="body"
            data-kt-toggle-name="aside-minimize"
            onClick={toggleAsideMinimize}
          >
            <span
              className="svg-icon svg-icon-1"
              onClick={handleRotate}
              style={{
                cursor: "pointer",
                transform: `rotate(${rotateAngle}deg)`,
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width={24}
                height={24}
                viewBox="0 0 24 24"
                fill="none"
              >
                <path
                  opacity="0.5"
                  d="M14.2657 11.4343L18.45 7.25C18.8642 6.83579 18.8642 6.16421 18.45 5.75C18.0358 5.33579 17.3642 5.33579 16.95 5.75L11.4071 11.2929C11.0166 11.6834 11.0166 12.3166 11.4071 12.7071L16.95 18.25C17.3642 18.6642 18.0358 18.6642 18.45 18.25C18.8642 17.8358 18.8642 17.1642 18.45 16.75L14.2657 12.5657C13.9533 12.2533 13.9533 11.7467 14.2657 11.4343Z"
                  fill="black"
                />
                <path
                  d="M8.2657 11.4343L12.45 7.25C12.8642 6.83579 12.8642 6.16421 12.45 5.75C12.0358 5.33579 11.3642 5.33579 10.95 5.75L5.40712 11.2929C5.01659 11.6834 5.01659 12.3166 5.40712 12.7071L10.95 18.25C11.3642 18.6642 12.0358 18.6642 12.45 18.25C12.8642 17.8358 12.8642 17.1642 12.45 16.75L8.2657 12.5657C7.95328 12.2533 7.95328 11.7467 8.2657 11.4343Z"
                  fill="black"
                />
              </svg>
            </span>
          </div>
        </div>
        <div className="aside-menu flex-column-fluid position-relative">
          <div
            className="hover-scroll-overlay-y my-5 my-lg-5"
            id="kt_aside_menu_wrapper"
            data-kt-scroll="true"
            data-kt-scroll-activate="{default: false, lg: true}"
            data-kt-scroll-height="auto"
            data-kt-scroll-dependencies="#kt_aside_logo, #kt_aside_footer"
            data-kt-scroll-wrappers="#kt_aside_menu"
            data-kt-scroll-offset={0}
          >
            <div
              className="menu menu-column menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500"
              id="#kt_aside_menu"
              data-kt-menu="true"
            >
              <div className="menu-item">
                <NavLink className="menu-link" to="/dashboard">
                  <span className="menu-icon">
                    <span className="svg-icon svg-icon-2">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 500 500"
                      >
                        <path
                          className="cls-1"
                          d="m65.28,241.34c-6.65,5.52-12.12,10.33-17.89,14.76-6.06,4.66-12.57,8.43-20.74,5.99-8.39-2.51-12.32-8.93-13.85-16.9-1.42-7.42,2.19-13.22,7.61-17.82,32.59-27.62,65.25-55.16,97.89-82.72,39.09-33.01,78.18-66.01,117.26-99.03,10.65-9,19.38-9.09,29.91-.17,71.35,60.5,142.68,121,214.02,181.51,12.67,10.74,9.87,29.51-5.23,34.97-7.77,2.81-13.94-.92-19.75-5.25-6.27-4.67-12.29-9.68-19.45-15.36v6.9c0,47.7.11,95.4-.06,143.09-.05,14.47-2.78,28.39-11.09,40.75-11.13,16.55-26.72,25.78-46.37,27.96-8.17.91-16.46,1.06-24.69,1.07-72.66.08-145.32.14-217.98-.03-17.45-.04-33.64-4.3-47.25-16.25-12.48-10.95-19.36-24.67-21.19-40.91-.92-8.17-1.07-16.45-1.09-24.69-.1-43.48-.05-86.96-.05-130.44v-7.46Zm105.71,180.06v-7.15c0-38.17-.02-76.34,0-114.5.01-22.87,13.76-36.54,36.75-36.55,28.26-.02,56.54.58,84.78-.19,21.71-.59,37.43,16.22,37.02,37.23-.74,38.15-.21,76.33-.21,114.5v7c12.45,0,24.32,0,36.2,0,20.44-.01,30.09-9.6,30.1-29.94,0-59.45-.04-118.91.09-178.36,0-4.23-1.22-7.01-4.49-9.77-34.18-28.91-68.21-58-102.29-87.03-12.82-10.92-25.66-21.83-38.63-32.86-1.16.86-2.05,1.45-2.86,2.14-46.51,39.61-93.05,79.2-139.43,118.96-1.86,1.59-3.19,4.89-3.2,7.4-.18,60.19-.14,120.37-.13,180.56,0,2.02,0,4.05.22,6.05,1.29,11.68,9.89,21.56,21.57,22.3,14.57.92,29.25.22,44.5.22Zm39.8-118.61v118.56h78.75v-118.56h-78.75Z"
                        />
                      </svg>
                    </span>
                  </span>
                  <span className="menu-title fs-5 mx-3">Home</span>
                </NavLink>
              </div>
              <div className="menu-item">
                <NavLink className="menu-link" to="/profile">
                  <span className="menu-icon">
                    <span className="svg-icon svg-icon-2">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        id="Layer_1"
                        viewBox="0 0 500 500"
                      >
                        <path d="M313.6 304c-28.7 0-42.5 16-89.6 16-47.1 0-60.8-16-89.6-16C60.2 304 0 364.2 0 438.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-25.6c0-74.2-60.2-134.4-134.4-134.4zM400 464H48v-25.6c0-47.6 38.8-86.4 86.4-86.4 14.6 0 38.3 16 89.6 16 51.7 0 74.9-16 89.6-16 47.6 0 86.4 38.8 86.4 86.4V464zM224 288c79.5 0 144-64.5 144-144S303.5 0 224 0 80 64.5 80 144s64.5 144 144 144zm0-240c52.9 0 96 43.1 96 96s-43.1 96-96 96-96-43.1-96-96 43.1-96 96-96z" />
                      </svg>
                    </span>
                  </span>
                  <span className="menu-title fs-5 mx-3">Profile</span>
                </NavLink>
              </div>
              <div className="menu-item">
                <NavLink
                  className="menu-link"
                  to="/contract"
                >
                  <span className="menu-icon">
                    <span className="svg-icon svg-icon-2">
                     <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" viewBox="0 0 500 500"><path d="m427.95,284.81c0,46.38.07,92.77-.04,139.15-.04,14.54-3.61,28.17-12.64,39.86-12.33,15.94-29.21,23.37-48.86,23.45-77.68.3-155.36.29-233.04.03-29.5-.1-51.84-17.9-59.27-46.46-1.43-5.51-1.97-11.39-1.98-17.1-.11-115.86-.1-231.71-.07-347.57,0-30.73,16.5-53.11,45.5-61.28,5.66-1.59,11.76-2.28,17.65-2.29,53.37-.17,106.73-.09,160.1-.11,19.24,0,35.57,6.35,49.2,20.4,20.66,21.3,41.67,42.28,62.93,62.98,14.16,13.78,20.61,30.26,20.56,49.78-.11,46.38-.03,92.77-.03,139.15ZM279.8,56.79h-6.31c-46.17,0-92.33-.01-138.5,0-13.11,0-18.7,5.67-18.7,18.91,0,116.3-.01,232.59,0,348.89,0,13.56,5.03,18.51,18.77,18.51,76.67.01,153.34.01,230.01,0,14.04,0,18.43-4.64,17.71-18.43-.09-1.65-.02-3.3-.02-4.95,0-83.51,0-167.02,0-250.53v-8.46c-2.93,0-5.15,0-7.37,0-21.02,0-42.05.38-63.06-.23-6.53-.19-13.6-1.89-19.35-4.94-10.62-5.63-13.11-16.27-13.15-27.47-.09-23.48-.03-46.96-.03-71.31Z"></path><path d="m249.92,220.39c23.91,0,47.82-.07,71.73.03,15.54.06,25.77,6.47,29.95,19.09,1.4,4.22,2,8.86,2.05,13.32.23,17.73.15,35.47.08,53.2-.08,21.46-11.42,32.83-32.88,32.86-47.2.06-94.4.06-141.6,0-21.51-.02-32.91-11.37-33.01-32.74-.08-17.73-.09-35.47,0-53.2.11-21.05,11.51-32.47,32.57-32.55,23.7-.09,47.41-.02,71.11-.02Z"></path><path d="m197.71,131.03c-11.72,0-23.45.16-35.16-.07-6.19-.12-11.95-1.89-14.64-8.27-2.31-5.46-2.22-11.11,2.08-15.49,2.27-2.32,5.8-4.75,8.79-4.8,26.07-.4,52.17-.89,78.22,0,10.42.35,15.03,10.04,11.41,19.94-2.65,7.25-9.04,8.47-15.53,8.62-11.72.27-23.44.08-35.16.07Z"></path><path d="m197.67,190.42c-11.72,0-23.45.17-35.16-.07-6.19-.12-11.94-1.92-14.61-8.31-2.29-5.46-2.4-11.42,2.18-15.41,3.28-2.86,8.17-5.3,12.39-5.39,23.64-.51,47.29-.45,70.94-.16,12.33.15,18.67,8.98,15.18,20.1-1.82,5.8-7.26,9.12-15.75,9.21-11.72.13-23.44.03-35.16.02Z"></path><path d="m301.75,398.3c-11.72,0-23.45.21-35.16-.06-12.15-.28-18.78-8.96-15.32-19.5,1.97-5.99,7.01-9.72,14.88-9.78,23.85-.2,47.71-.32,71.56.03,11.99.18,18.12,8.96,14.82,19.88-1.79,5.92-7.12,9.29-15.6,9.4-11.72.14-23.44.04-35.16.03Z"></path></svg>
                    </span>
                  </span>
                  <span className="menu-title fs-5 mx-3">Contract</span>
                </NavLink>
              </div>
              <div className="menu-item">
                <NavLink
                  className="menu-link"
                  to="/address_book"
                >
                  <span className="menu-icon">
                    <span className="svg-icon svg-icon-2">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M272 288h-64C163.8 288 128 323.8 128 368C128 376.8 135.2 384 144 384h192c8.836 0 16-7.164 16-16C352 323.8 316.2 288 272 288zM240 256c35.35 0 64-28.65 64-64s-28.65-64-64-64c-35.34 0-64 28.65-64 64S204.7 256 240 256zM496 320H480v96h16c8.836 0 16-7.164 16-16v-64C512 327.2 504.8 320 496 320zM496 64H480v96h16C504.8 160 512 152.8 512 144v-64C512 71.16 504.8 64 496 64zM496 192H480v96h16C504.8 288 512 280.8 512 272v-64C512 199.2 504.8 192 496 192zM384 0H96C60.65 0 32 28.65 32 64v384c0 35.35 28.65 64 64 64h288c35.35 0 64-28.65 64-64V64C448 28.65 419.3 0 384 0zM400 448c0 8.836-7.164 16-16 16H96c-8.836 0-16-7.164-16-16V64c0-8.838 7.164-16 16-16h288c8.836 0 16 7.162 16 16V448z"></path></svg>
                    </span>
                  </span>
                  <span className="menu-title fs-5 mx-3">Address Book</span>
                </NavLink>
              </div>
              <div className="menu-item" >
                <div className="menu-link" onClick={() => dropdown(height, setHeight)}>
                  <span className="menu-icon">
                    <span className="svg-icon svg-icon-2">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500"><path d="m182.3,248.72c0-60.29-.03-120.59.03-180.88.01-12.47,2.89-24.18,10.12-34.62,9.32-13.44,22.98-19.64,38.45-20.5,15.42-.86,31.22-1.04,46.41,1.34,24.67,3.86,40.37,25.61,40.41,52.91.08,61.47.02,122.94.02,184.42,0,59.82.24,119.65-.25,179.47-.07,9.14-2.13,18.84-5.68,27.27-7.81,18.54-23.78,26.91-43,28.31-13.31.97-26.97,1.24-40.13-.62-30.41-4.29-46.35-23.88-46.37-54.79-.03-60.77-.01-121.53-.01-182.3Zm51.08-185.75v372.85h33.27V62.97h-33.27Z"></path><path d="m351.98,283.5c0-49.22-.36-98.45.31-147.66.13-9.76,3.05-19.96,6.81-29.08,6.14-14.86,19.15-23.17,34.41-24.97,15.97-1.88,32.5-2.27,48.45-.45,28.17,3.21,45.31,23.43,45.37,51.93.22,100.09.23,200.18,0,300.27-.07,30.46-20.03,51.46-50.82,53.08-14.95.78-30.36.86-44.97-1.9-24.92-4.7-39.51-25.56-39.55-52.86-.07-49.46-.02-98.91-.02-148.37Zm50.93,152.22h33.33V131.18h-33.33v304.54Z"></path><path d="m148.07,352.03c0,26.84.10,53.68-.03,80.52-.13,26.35-14.05,46.12-38.14,51.85-19.36,4.6-39.4,4.63-58.73.06-24.23-5.72-38.34-24.99-38.46-50.85-.25-54.86-.29-109.72.01-164.57.17-30.29,20.29-51.45,50.88-53.04,14.72-.76,29.83-.74,44.29,1.71,24.52,4.15,40.03,25.53,40.16,52.39.13,27.31.03,54.62.03,81.93Zm-50.88-85.24h-33.51v169.06h33.51v-169.06Z"></path></svg>
                    </span>
                  </span>
                  <span className="menu-title fs-5 mx-3">Reports</span>
                </div>
              </div>

              <div className={height} >
                <ul>
                  <div className="menu-item"  >
                    <NavLink
                      className="menu-link "
                      to="/contaracthistory"
                      activeclassname="active"
                    >
                      <span className="menu-title fs-5 mx-3">Contract Utilization History</span>
                    </NavLink>
                  </div>
                  <div className="menu-item">
                    <NavLink
                      className="menu-link"
                      to="/contaractransaction"
                      activeclassname="active"
                    >
                      <span className="menu-title fs-5 mx-3">Contract Financial Transaction</span>
                    </NavLink>
                  </div>
                  <div className="menu-item">
                    <NavLink
                      className=" menu-link"
                      to="/membershiptransaction"
                      activeclassname="active"
                    >
                      <span className="menu-title fs-5 mx-3"> Membership Transaction</span>
                    </NavLink>
                  </div>
                  <div className="menu-item">
                    <NavLink
                      className="menu-link "
                      to="/exportcontractlist"
                      activeclassname="active"
                      
                    >
                      <span className="menu-title fs-5 mx-3"> Export Contract List</span>
                    </NavLink>
                  </div>
                  <div className="menu-item">
                    <NavLink
                      className="menu-link "
                      to="/exportcontactlist"
                      activeclassname="active"
                    >
                      <span className="menu-title fs-5 mx-3">Export Contact List</span>
                    </NavLink>
                  </div>
                </ul>
              </div>

            
              <div className="menu-item">
                <NavLink
                  className="menu-link"
                  to="../../demo1/dist/dashboards/only-header.html"
                >
                  <span className="menu-icon">
                    <span className="svg-icon svg-icon-2">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 576 512"
                      >
                        <path d="M534.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L434.7 224 224 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l210.7 0-73.4 73.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l128-128zM192 96c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0c-53 0-96 43-96 96l0 256c0 53 43 96 96 96l64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0c-17.7 0-32-14.3-32-32l0-256c0-17.7 14.3-32 32-32l64 0z" />
                      </svg>
                    </span>
                  </span>
                  <span className="menu-title fs-5 mx-3">Log Out</span>
                </NavLink>
              </div>
            </div>
          </div>
          <div className="aside-footer flex-column-auto pt-5 ms-1 pb-5 menu menu-column menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500 position-absolute bottom-0">
            <div className="menu-item">
              <NavLink className="menu-link">
                <span className="menu-icon">
                  <span className="svg-icon svg-icon-2">
                    <img
                      src={sidebar_footer_logo}
                      className="rounded-circle"
                      style={{ height: 40, width: 40 }}
                    />
                  </span>
                </span>
                <span className="menu-title fs-5 fw-bolder cursor-default ms-5">
                  UserInterprising Pvt Ltd
                </span>
              </NavLink>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
