import React from 'react';
import Select from 'react-select';

const SelectComponents = ({Options}) => {
    return (
        <div>
            <Select
                className="basic-single"
                classNamePrefix="select"
                isClearable
                isSearchable
                name="color"
                options={Options}
            />

        </div>
    );
};

export default SelectComponents;