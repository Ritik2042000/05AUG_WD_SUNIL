import React from 'react';
import { useNavigate } from "react-router-dom"

const Login = () => {
    const navigate = useNavigate()
 

    const businessLogin = () => {
        navigate("/authLogin/sfdvsfhjgjggvfs/business")
    }

    return (
        <div style={{ display: "flex", justifyContent: "center", marginTop: "100px", gap: "10px" }}>
            <button style={{ padding: "4px" }}
                onClick={businessLogin}
            >Business Login</button>

            <button style={{ padding: "4px" }}
                onClick={() => navigate("/authLogin/sfdvgjhyggiuvsfvfs/individual")}
            >Individual Login</button>
        </div>
    )
}

export default Login