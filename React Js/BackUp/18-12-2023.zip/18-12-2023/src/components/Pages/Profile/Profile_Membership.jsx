import React from 'react'

const Profile_Membership = () => {
    return (
        <>
            <div className="membership_otr py-3">
                <div className="table-responsive">
                    <div className='d-flex justify-content-between my-7'>
                        <div className='membership_details'>
                            <h4>Current Membership</h4>
                            <p>Basic Membership</p>
                            <p className='mb-0'>Membership Expiry Date -13-11-2022 23:59:59</p>
                        </div>
                        <div className='button_right'>
                            <button className="btn btn-primary btn-sm">Upgrade</button>
                            <button className="ms-2 btn btn-primary btn-sm">Renew</button>
                        </div>
                    </div>

                    <div className='separator border-3 mb-10'></div>

                    <div className=''>
                        <h4>Contracts</h4>
                        <p>Contract Available - 5</p>
                        <p>Contracts Used - 0</p>
                        <h4 className=''>Buy Additional Contracts</h4>

                        <table className="number_of_contracts table table-row-dashed table-row-gray-300 gy-7">
                            <tbody>
                                <tr>
                                    <td>Number of Contracts</td>
                                    <td>
                                        <input type="number" className="form-control form-control-solid form-control-sm" />
                                    </td>
                                    <td>X</td>
                                    <td>KD 1.000</td>
                                    <td>=</td>
                                    <td id="result">KD 0.000</td>
                                </tr>
                            </tbody>
                        </table>
                        <div className='d-flex justify-content-end mb-10'>
                            <button className='btn btn-sm btn-warning text-dark text-end'>Pay Now</button>
                        </div>

                    </div>
                </div>
            </div >
        </>
    )
}

export default Profile_Membership