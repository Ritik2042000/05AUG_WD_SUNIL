import React from "react";
import user_img from "../../../assets/images/arab-man.jpg";
import Profile_Notification from "./Profile_Notification";
import Profile_Membership from "./Profile_Membership";
import ProfileDetails from "./PersonalDetails";

const Profile = () => {
  return (
    <>
      <div
        className="content d-flex flex-column flex-column-fluid pt-0"
        id="kt_content"
      >
        {/*begin::Post*/}
        <div className="post d-flex flex-column-fluid" id="kt_post">
          {/*begin::Container*/}
          <div id="kt_content_container" className="container-xxl mt-10">
            {/*begin::Toolbar*/}
            <div className="toolbar" id="kt_toolbar">
              {/*begin::Container*/}
              <div id="kt_toolbar_container" className="d-flex flex-stack">
                {/*begin::Page title*/}
                <div
                  data-kt-swapper="true"
                  data-kt-swapper-mode="prepend"
                  data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                  className="page-title d-flex align-items-center flex-wrap me-3 mb-5"
                >
                  {/*begin::Title*/}
                  <h1 className="d-flex align-items-center text-dark fw-bolder fs-3 my-1">
                    Profile
                  </h1>
                  {/*end::Title*/}
                </div>
                {/*end::Page title*/}
              </div>
              {/*end::Container*/}
            </div>
            {/*end::Toolbar*/}
            <div className="profile_otr">
              <div className="d-flex flex-column flex-xl-row">
                <div className="Profile_user_otr flex-column flex-lg-row-auto w-100 w-xl-350px mb-10 ">
                  <div className="card mb-5 mb-xl-8">
                    <div className="card-body pt-15 h-100">
                      <div className="d-flex flex-center flex-column mb-5">
                        <div className="user_img mb-3">
                          <img src={user_img} className="rounded-circle"></img>
                        </div>
                        <div className="user_id fs-5 fw-bold text-muted mb-1">
                          ID: 975078
                        </div>
                        <div className="membershio">
                          <button className="btn btn-primary btn-sm">Free Membership</button>
                        </div>
                      </div>
                      <div className="separator separator-dashed my-3"></div>
                      <div className="user_details pb-5 fs-6">
                        <div className="fw-bolder mt-5">Creation Date</div>
                        <div className="text-gray-600">
                          14-11-2022 13:45:30 - <span className="text-danger">Not Verified</span>
                        </div>
                        <div className="fw-bolder mt-5">Status:</div>
                        <div className="text-gray-600">Active</div>
                        <div className="fw-bolder mt-5">Account Type</div>
                        <div class="text-gray-600">Individual</div>
                        <div className="fw-bolder mt-5">Last Activity</div>
                        <div className="text-gray-600">24-11-2022 14:45:38</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="personal_details_otr col">
                  <div className="card" style={{ minHeight: "93%" }}>
                    <div className="card-body pt-3">
                      <div className="business-panel-tabs">
                        <ul className="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-4">
                          <li className="nav-item">
                            <a
                              className="nav-link text-active-primary pb-4 mx-2 active border-active-primary "
                              data-bs-toggle="tab"
                              href="#kt_tab_pane_1"
                            >
                              Profile
                            </a>
                          </li>
                          <li className="nav-item">
                            <a
                              className="nav-link text-active-primary pb-4 mx-2 border-active-primary "
                              data-bs-toggle="tab"
                              href="#kt_tab_pane_2"
                            >
                              Notification
                            </a>
                          </li>
                          <li className="nav-item">
                            <a
                              className="nav-link text-active-primary pb-4 mx-2 border-active-primary"
                              data-bs-toggle="tab"
                              href="#kt_tab_pane_3"
                            >
                              Membership & Contracts
                            </a>
                          </li>
                        </ul>
                        <div className="tab-content" id="myTabContent">
                          <div
                            className="tab-pane fade show active"
                            id="kt_tab_pane_1"
                            role="tabpanel"
                          >
                            <ProfileDetails />
                          </div>
                          <div
                            className="tab-pane fade"
                            id="kt_tab_pane_2"
                            role="tabpanel"
                          >
                            <Profile_Notification />
                          </div>
                          <div
                            className="tab-pane fade"
                            id="kt_tab_pane_3"
                            role="tabpanel"
                          >
                            <Profile_Membership />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/*end::Container*/}
        </div>
        {/*end::Post*/}
      </div>
    </>
  );
};

export default Profile;
