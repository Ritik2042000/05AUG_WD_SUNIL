import React from 'react'
import SelectComponents from '../../CommonLayouts/SelectComponents'

const ProfileDetails = () => {

    const selectData = [
        { value: 'Recently Updated', label: 'Recently Updated' },
        { value: 'Last Month', label: 'Last Month' },
        { value: 'Last Quarter', label: 'Last Quarter' },
        { value: 'Last Year', label: 'Last Year' }
    ]

    return (
        <div className="personal_details_otr">
            <div className='heading_details'>
                <h4>Personal Details</h4>
            </div>
            <form>
                <div className="personal_details_content">
                    <div className="row flex-wrap">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Full Name
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    الإسم الكامل
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Email
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Civil ID
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Phone Number
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Date of Birth
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Gender
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    
                                    
                                    
                                />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    الجنس
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Address Type
                                </label>
                                <SelectComponents Options={selectData} />

                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    نوع العنوان
                                </label>
                                <SelectComponents Options={selectData} />
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Nationality
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    الجنسية
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Area
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    المنطقة
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    id="contractwords"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Block
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg" />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    قطعة
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    id="contractwords"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    Street Name/Number
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"/>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    اسم الشارع/الرقم
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    id="contractwords"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    House/Building Number
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                />
                            </div>
                        </div>
                        <div className="col-12 col-sm-6">
                            <div className="flied pb-6 text-end">
                                <label htmlFor="contractwords" className="font-english fs-6 fw-bolder text-dark form-label required">
                                    رقم المنزل/المبنى
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    id="contractwords"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    )
}

export default ProfileDetails
