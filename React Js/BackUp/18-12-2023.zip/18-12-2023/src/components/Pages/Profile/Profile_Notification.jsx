import React from 'react'

const Profile_Notification = () => {
    return (
        <>
            <div className="notification_otr py-3">
                <div className="table-responsive">
                    <div className="print_report_btn">
                        <button className="btn btn-primary">Save</button>
                    </div>
                    <h4 className="my-0">Notifications</h4>
                    <p className="mb-5">Set your notification preference for when you
                        are in or away from the dashboard<br />You need to configure
                        your settings to allow notification from Tothing.com:
                    </p>

                    <label className="form-check form-check-custom form-check-solid">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">New comments</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid my-3">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">Status Changes</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">Membership expiration</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid my-3">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">User add on</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">Deleting contracts</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid my-3">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">Reviewed contracts</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">Contract Signatures</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid my-3">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">Canceled contracts</span>
                    </label>
                    <label className="form-check form-check-custom form-check-solid">
                        <input className="form-check-input" type="checkbox" name="new_comment_enabled" defaultValue="true" />
                        <span className="form-check-label">Draft contracts</span>
                    </label>
                    <div className="notification_tab_inr_section row mx-0">
                        <div className="col-6 notification_tab_left">
                            <h5 className="mt-8 mb-5">When you receive a notification</h5>
                            <div className="form-check form-switch form-check-custom form-check-solid">
                                <input className="form-check-input" type="checkbox" name="chat_sound_enabled" defaultValue="true" />
                                <label className="form-check-label" htmlFor="flexSwitchChecked">Play a sound</label>
                            </div>
                            <div className="form-check form-switch form-check-custom form-check-solid my-3">
                                <input className="form-check-input" type="checkbox" name="chat_sound_enabled" defaultValue="true" />
                                <label className="form-check-label" htmlFor="flexSwitchChecked">Highlight the bell icon in the system tray </label>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default Profile_Notification