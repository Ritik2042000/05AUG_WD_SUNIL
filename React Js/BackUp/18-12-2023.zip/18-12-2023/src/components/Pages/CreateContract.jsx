import React from 'react';
import Contract_Step1 from './CreateContract/Contract_Step1';
import Contract_Step2 from './CreateContract/Contract_Step2';
import Contract_Step3 from './CreateContract/Contract_step3';

const CreateContract = () => {
    return (
        <>

            <div
                className="content d-flex flex-column flex-column-fluid pt-0"
                id="kt_content"
            >
                {/*begin::Post*/}
                <div className="post d-flex flex-column-fluid" id="kt_post">
                    {/*begin::Container*/}
                    <div id="kt_content_container" className="container-xxl mt-10">
                        {/*begin::Toolbar*/}
                        <div className="toolbar" id="kt_toolbar">
                            {/*begin::Container*/}
                            <div id="kt_toolbar_container" className="d-flex flex-stack">
                                {/*begin::Page title*/}
                                <div
                                    data-kt-swapper="true"
                                    data-kt-swapper-mode="prepend"
                                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                    className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                >
                                    {/*begin::Title*/}
                                    <h1 className="d-flex align-items-center text-dark fw-bolder fs-3 my-1 pb-4">
                                        Create Contract
                                    </h1>
                                    {/*end::Title*/}
                                </div>
                                {/*end::Page title*/}
                            </div>
                            {/*end::Container*/}
                        </div>
                        {/*end::Toolbar*/}
                        <div className='create_contract_step my-5'>
                            <ul className="nav  nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                                <li className="nav-item">
                                    <a
                                        className="nav-link text-active-primary pb-4 mx-2 active border-active-primary"
                                        data-bs-toggle="tab"
                                        href="#kt_tab_pane_1"
                                    >
                                        Step-1
                                    </a>
                                </li>
                                <li className="nav-item">
                                    <a
                                        className="nav-link text-active-primary pb-4 mx-2 border-active-primary"
                                        data-bs-toggle="tab"
                                        href="#kt_tab_pane_2"
                                    >
                                        Step-2
                                    </a>
                                </li>
                                <li className="nav-item">
                                    <a
                                        className="nav-link text-active-primary pb-4 mx-2 border-active-primary"
                                        data-bs-toggle="tab"
                                        href="#kt_tab_pane_3"
                                    >
                                        Step-3
                                    </a>
                                </li>
                            </ul>
                            <div className='col-4 '>
                                {/* <button className="continue_contract btn btn-sm">Continue</button>
                                <button className="cancel_contract btn btn-sm">Cancel</button> */}
                                 <div className="mb-2 text-center ">
                                    <span className="bg-warning bg-opacity-50 text-bolder text-danger text-center">For basic and premium members</span>
                                </div>
                                <div className="create_cont_btn_inr d-flex justify-content-end ">
                                    <div className=" me-5">
                                        <button className="btn btn-sm btn-primary">Create Blank Contract</button>
                                    </div>
                                    <div className="">
                                        <button className="btn btn-sm btn-primary">Upload Document</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="tab-content" id="myTabContent">
                            <div
                                className="tab-pane fade show active"
                                id="kt_tab_pane_1"
                                role="tabpanel"
                            >
                                <Contract_Step1 />

                            </div>
                            <div
                                className="tab-pane fade"
                                id="kt_tab_pane_2"
                                role="tabpanel"
                            >
                                <Contract_Step2 />

                            </div>
                            <div
                                className="tab-pane fade"
                                id="kt_tab_pane_3"
                                role="tabpanel"
                            >
                                <Contract_Step3 />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    );
};

export default CreateContract;