import { Pagination } from "@mui/material";
import React, { useState } from "react";

const ContractUtilization = () => {

    // pagination state
    const [currentPage, setCurrentPage] = useState(1);
    // number of data that show on one page
    const itemsPerPage = 10;

    const tableData = [
        {
            month: "October 2023",
            membership: "5",
            contracts: "0",
            carray_forword_contract: "0",
            total_contract: "5",
            contract_utilization: "1",
            remaining_contacts: "4"
        },
        {
            month: "November 2023",
            membership: "0",
            contracts: "0",
            carray_forword_contract: "0",
            total_contract: "0",
            contract_utilization: "1",
            remaining_contacts: "-1"
        },
        {
            month: "December 2023",
            membership: "0",
            contracts: "1",
            carray_forword_contract: "0",
            total_contract: "1",
            contract_utilization: "4",
            remaining_contacts: "-3"
        },
    ]

    // pagination functions
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = tableData.slice(indexOfFirstItem, indexOfLastItem);

    // Function to handle page change
    const handlePageChange = (event, value) => {
        setCurrentPage(value);
    };
    return (
        <>
            <div
                className="content d-flex flex-column flex-column-fluid pt-0"
                id="kt_content"
            >
                {/*begin::Post*/}
                <div className="post d-flex flex-column-fluid" id="kt_post">
                    {/*begin::Container*/}
                    <div id="kt_content_container" className="container-xxl mt-10">
                        {/*begin::Toolbar*/}
                        <div className="toolbar" id="kt_toolbar">
                            {/*begin::Container*/}
                            <div id="kt_toolbar_container" className="d-flex flex-stack">
                                {/*begin::Page title*/}
                                <div
                                    data-kt-swapper="true"
                                    data-kt-swapper-mode="prepend"
                                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                    className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                >
                                    {/*begin::Title*/}
                                    <h1 className="d-flex align-items-center text-dark fw-bolder px-3 fs-3 my-1 py-3 py-lg-6">
                                        Contract Utilization History
                                    </h1>
                                    {/*end::Title*/}
                                </div>
                                {/*end::Page title*/}
                            </div>
                            {/*end::Container*/}
                        </div>
                        {/*end::Toolbar*/}
                        <div className="report_otr">
                            {/* <div className="business-panel-tabs mt-5"> */}
                            <div className="card">
                                <div className="card-body">
                                    <div className="d-flex justify-content-end">

                                        <div className="mb-0 p-3">
                                            <button className="btn btn-sm btn-primary">Download</button>
                                        </div>
                                    </div>

                                    <div className="table-responsive ">
                                        <table className="table  table-row-dashed gs-7 gy-5 ">
                                            <thead>
                                                <tr className="text-start text-dark-400 fw-bolder fs-7 text-uppercase gs-0">
                                                    <th className="min-w-150px">MONTH</th>
                                                    <th className="min-w-150px">TOTAL MEMBERSHIP CONTRACT</th>
                                                    <th className="min-w-150px">ADDITIONAL CONTRACTS</th>
                                                    <th className="min-w-150px" style={{ width: '167px' }}>CARRY FORWARD CONTRACT (I DON'T UNDERSTAND THIS LINE WHAT IS IT FOR?)</th>
                                                    <th className="min-w-150px">TOTAL CONTRACTS </th>
                                                    <th className="min-w-150px">CONTRACT UTILIZATION</th>
                                                    <th className="min-w-150px">REMAINING CONTRACTS</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    tableData.map((items, index) => {
                                                        return <tr key={index}>
                                                            <td>{items.month}</td>
                                                            <td>{items.membership}</td>
                                                            <td>{items.contracts}</td>
                                                            <td>{items.carray_forword_contract}</td>
                                                            <td>{items.total_contract}</td>
                                                            <td>{items.contract_utilization}</td>
                                                            <td>{items.remaining_contacts}</td>
                                                        </tr>
                                                    })
                                                }

                                            </tbody>
                                        </table>
                                    </div>
                                    <div className="d-flex justify-content-center mt-10 mb-10"
                                    >
                                        <Pagination
                                            count={Math.ceil(tableData.length / itemsPerPage)}
                                            page={currentPage}
                                            onChange={handlePageChange}
                                            shape="rounded"
                                            showLastButton
                                            showFirstButton
                                            color="primary"

                                        />
                                    </div>

                                </div>
                            </div>
                            {/* </div> */}
                        </div>
                    </div>
                    {/*end::Container*/}
                </div>
                {/*end::Post*/}
            </div>
        </>
    );
};

export default ContractUtilization;
