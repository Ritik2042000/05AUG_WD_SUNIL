import { Pagination } from '@mui/material';
import React, { useState } from 'react';

const ExportContactList = () => {

    // search state
    const [searchData, setSearchData] = useState('')

    // pagination state
    const [currentPage, setCurrentPage] = useState(1);
    // number of data that show on one page
    const itemsPerPage = 10;

    const tableData = [
        {
            CONTACTNAME: 'Jack Mackwan',
            EMAIL: 'afok45961@undewp.com',
            PHONENUMBER: '5642138',
        },
        {
            CONTACTNAME: 'Darshan Patoliya',
            EMAIL: 'darshan@mailinator.com',
            PHONENUMBER: '12345679',
        }
    ]

    // search Functions
    const filteredTableData = tableData.filter((item) =>
        item.CONTACTNAME.toLowerCase().includes(searchData.toLowerCase()) ||
        item.EMAIL.toLowerCase().includes(searchData.toLowerCase()) ||
        item.PHONENUMBER.toLowerCase().includes(searchData.toLowerCase())
    );

    // pagination functions
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = tableData.slice(indexOfFirstItem, indexOfLastItem);

    // Function to handle page change
    const handlePageChange = (event, value) => {
        setCurrentPage(value);
    };

    return (
        <>
            {/* <div className="mb-20 post d-flex flex-column-fluid">
                <div className="mb-10 container-xxl mt-10">
                    <div className="container-xxl">
                        <div className="app-toolbar py-3 py-lg-6">
                            <div className="app-container px-3 d-flex flex-stack">
                                <div className="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                    <h1 className="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Export Contract List</h1>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div> */}
            <div
                className="content d-flex flex-column flex-column-fluid pt-0"
                id="kt_content"
            >
                {/*begin::Post*/}
                <div className="post d-flex flex-column-fluid" id="kt_post">
                    {/*begin::Container*/}
                    <div id="kt_content_container" className="container-xxl mt-10">
                        {/*begin::Toolbar*/}
                        <div className="toolbar" id="kt_toolbar">
                            {/*begin::Container*/}
                            <div id="kt_toolbar_container" className="d-flex flex-stack">
                                {/*begin::Page title*/}
                                <div
                                    data-kt-swapper="true"
                                    data-kt-swapper-mode="prepend"
                                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                    className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                >
                                    {/*begin::Title*/}
                                    <h1 className="d-flex align-items-center text-dark fw-bolder fs-3 my-1 px-3 py-3 py-lg-6">
                                        Export Contract List
                                    </h1>
                                    {/*end::Title*/}
                                </div>
                                {/*end::Page title*/}
                            </div>
                            {/*end::Container*/}
                        </div>
                        {/*end::Toolbar*/}
                        <div className="card">
                            <div className="card-body">
                                <div className="d-flex justify-content-md-end flex-wrap">
                                    <div className="mb-0 p-3">
                                        <div className="w-100 mb-5 mb-lg-0 position-relative">
                                            <form data-kt-search-element="form" className=" d-lg-block w-100 mb-lg-0 position-relative" >
                                                <span className="svg-icon svg-icon-2 svg-icon-gray-700 position-absolute top-50 translate-middle-y ms-4"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect><path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor">
                                                    </path>
                                                </svg>
                                                </span>
                                                <input className="form-control form-control-solid h-40px bg-body ps-13 fs-7" type="text" id="filter" value={searchData} placeholder="Search Contact" onChange={(e) => setSearchData(e.target.value)} />
                                            </form>
                                        </div>
                                    </div>
                                    <div className="mb-0 p-3">
                                        <button className="btn btn-sm btn-primary">Download</button>
                                    </div>
                                </div>
                                <div className="table-responsive   ">

                                    <table className="table-responsive table table-row-dashed gy-7 gs-7">
                                        <thead>
                                            <tr className="fw-bolder fs-7 text-gray-800 ">
                                                <th className="min-w-100px">CONTACT NAME</th>
                                                <th className="min-w-200px">EMAIL</th>
                                                <th className="min-w-100px">PHONE NUMBER</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                filteredTableData.map((items, key) => {
                                                    return <tr key={key}>
                                                        <td>{items.CONTACTNAME}</td>
                                                        <td>{items.EMAIL}</td>
                                                        <td>{items.PHONENUMBER}</td>
                                                    </tr>
                                                })
                                            }

                                        </tbody>
                                    </table>
                                </div>
                                <div className="d-flex justify-content-center mt-10 mb-10"
                                >
                                    <Pagination
                                        count={Math.ceil(tableData.length / itemsPerPage)}
                                        page={currentPage}
                                        onChange={handlePageChange}
                                        shape="rounded"
                                        showLastButton
                                        showFirstButton
                                        color="primary"

                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*end::Container*/}
                </div>
                {/*end::Post*/}
            </div>


        </>
    );
};

export default ExportContactList;

