import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import React, { useState } from 'react';
import Pagination from '@mui/material/Pagination';



const MemberShipTransaction = () => {

    // pagination state
    const [currentPage, setCurrentPage] = useState(1);
    // number of data that show on one page
    const itemsPerPage = 10; 


    const tableData = [
        {
            TRANSACTIONDATE: '27/10/2023',
            TRANSACTIONID: '330001001019049',
            PAYMENTMODE: 'myfatoorah',
            MEMBERSHIPINFORMATION: 'Basic membership',
            STARTDATE: '',
            ENDDATE: '',
            AMOUNT: '57',
            PAYMENTSTATUS: 'failed',
        },
        {
            TRANSACTIONDATE: '30/10/2023',
            TRANSACTIONID: '330301000529394',
            PAYMENTMODE: 'myfatoorah',
            MEMBERSHIPINFORMATION: 'Basic membership',
            STARTDATE: '',
            ENDDATE: '',
            AMOUNT: '57',
            PAYMENTSTATUS: 'failed',
        },
        {
            TRANSACTIONDATE: '04/12/2023',
            TRANSACTIONID: 'myfatoorah',
            PAYMENTMODE: '',
            MEMBERSHIPINFORMATION: 'Basic membership',
            STARTDATE: '',
            ENDDATE: '',
            AMOUNT: '57',
            PAYMENTSTATUS: 'pending',
        },

    ]

    // pagination functions
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = tableData.slice(indexOfFirstItem, indexOfLastItem);

    // Function to handle page change
    const handlePageChange = (event, value) => {
        setCurrentPage(value);
    };

    return (
        // <div className="mb-20 post d-flex flex-column-fluid">
        //     <div className="mb-10 container-xxl mt-10">
        //         <div className="container-xxl">
        //             <div className="app-toolbar py-3 py-lg-6">
        //                 <div className="app-container px-3 d-flex flex-stack">
        //                     <div className="page-title d-flex flex-column justify-content-center flex-wrap me-3">
        //                         <h1 className="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Membership Transaction</h1>
        //                     </div>
        //                 </div>
        //             </div>


        //             <div className="card">
        //                 <div className="card-body">
        //                     <div className="d-flex justify-content-end">
        //                         <div className="mb-0 p-3">
        //                             <div className="react-datepicker-wrapper">
        //                                 <div className="react-datepicker__input-container">
        //                                     {/* <input type="date" placeholder="Select start date" className="form-control form-control-solid" /> */}
        //                                     <LocalizationProvider dateAdapter={AdapterDayjs}>
        //                                         <DatePicker />
        //                                     </LocalizationProvider>
        //                                 </div>
        //                             </div>
        //                         </div>
        //                         <div className="mb-0 p-3">
        //                             <div className="react-datepicker-wrapper">
        //                                 <div className="react-datepicker__input-container">
        //                                     {/* <input type="date" placeholder="Select end date" className="form-control form-control-solid" /> */}
        //                                     <LocalizationProvider dateAdapter={AdapterDayjs}>
        //                                         <DatePicker />
        //                                     </LocalizationProvider>
        //                                 </div>
        //                             </div>
        //                         </div>
        //                         <div className="mb-0 p-3">
        //                             <button className="btn btn-sm btn-primary">Download</button>
        //                         </div>
        //                     </div>
        //                     <div className="table-responsive   ">

        //                         <table className="table-responsive  table table-row-dashed gy-7 gs-7">
        //                             <thead>
        //                                 <tr className="fw-bolder fs-7 text-gray-800 border-bottom-2 border-gray-200">
        //                                     <th className="min-w-100px">TRANSACTION DATE</th>
        //                                     <th className="min-w-200px">TRANSACTION ID</th>
        //                                     <th className="min-w-100px">PAYMENT MODE</th>
        //                                     <th className="min-w-200px">MEMBERSHIP INFORMATION</th>
        //                                     <th className="min-w-100px">STARTDATE</th>
        //                                     <th className="min-w-100px">ENDDATE</th>
        //                                     <th className="min-w-100px">AMOUNT</th>
        //                                     <th className="min-w-100px">PAYMENTSTATUS</th>
        //                                 </tr>
        //                             </thead>
        //                             <tbody>
        //                                 {
        //                                     tableData.map((items, key) => {
        //                                         return <tr key={key}>
        //                                             <td>{items.TRANSACTIONDATE}</td>
        //                                             <td>{items.TRANSACTIONID}</td>
        //                                             <td>{items.PAYMENTMODE}</td>
        //                                             <td>{items.MEMBERSHIPINFORMATION}</td>
        //                                             <td>{items.INFORMATION}</td>
        //                                             <td>{items.STARTDATE}</td>
        //                                             <td>{items.ENDDATE}</td>
        //                                             <td>{items.PAYMENTSTATUS}</td>
        //                                         </tr>
        //                                     })
        //                                 }

        //                             </tbody>
        //                         </table>
        //                     </div>
        //                 </div>
        //             </div>
        //         </div>
        //     </div>
        // </div>
        <div
            className="content d-flex flex-column flex-column-fluid pt-0"
            id="kt_content"
            
        >
            {/*begin::Post*/}
            <div className="post d-flex flex-column-fluid" id="kt_post">
                {/*begin::Container*/}
                <div id="kt_content_container" className="container-xxl mt-10">
                    {/*begin::Toolbar*/}
                    <div className="toolbar" id="kt_toolbar">
                        {/*begin::Container*/}
                        <div id="kt_toolbar_container" className="d-flex flex-stack">
                            {/*begin::Page title*/}
                            <div
                                data-kt-swapper="true"
                                data-kt-swapper-mode="prepend"
                                data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                            >
                                {/*begin::Title*/}
                                <h1 className="d-flex align-items-center text-dark fw-bolder px-3 py-3 py-lg-6 fs-3 my-1">
                                    Membership Transaction
                                </h1>
                                {/*end::Title*/}
                            </div>
                            {/*end::Page title*/}
                        </div>
                        {/*end::Container*/}
                    </div>
                    {/*end::Toolbar*/}
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-md-end flex-wrap">
                                <div className="mb-0 p-3">
                                    <div className="react-datepicker-wrapper">
                                        <div className="react-datepicker__input-container">
                                            {/* <input type="date" placeholder="Select start date" className="form-control form-control-solid" /> */}
                                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                <DatePicker />
                                            </LocalizationProvider>
                                        </div>
                                    </div>
                                </div>
                                <div className="mb-0 p-3">
                                    <div className="react-datepicker-wrapper">
                                        <div className="react-datepicker__input-container">
                                            {/* <input type="date" placeholder="Select end date" className="form-control form-control-solid" /> */}
                                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                <DatePicker />
                                            </LocalizationProvider>
                                        </div>
                                    </div>
                                </div>
                                <div className="mb-0 p-3">
                                    <button className="btn btn-sm btn-primary">Download</button>
                                </div>
                            </div>
                            <div className="table-responsive">
                                <table className="table-responsive table table-row-dashed gy-7 gs-7">
                                    <thead>
                                        <tr className="fw-bolder text-dark fs-7 text-gray-800 ">
                                            <th className="min-w-100px">TRANSACTION DATE</th>
                                            <th className="min-w-200px">TRANSACTION ID</th>
                                            <th className="min-w-100px">PAYMENT MODE</th>
                                            <th className="min-w-200px">MEMBERSHIP INFORMATION</th>
                                            <th className="min-w-100px">STARTDATE</th>
                                            <th className="min-w-100px">ENDDATE</th>
                                            <th className="min-w-100px">AMOUNT</th>
                                            <th className="min-w-100px">PAYMENTSTATUS</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            tableData.map((items, key) => {
                                                return <tr key={key}>
                                                    <td>{items.TRANSACTIONDATE}</td>
                                                    <td>{items.TRANSACTIONID}</td>
                                                    <td>{items.PAYMENTMODE}</td>
                                                    <td>{items.MEMBERSHIPINFORMATION}</td>
                                                    <td>{items.INFORMATION}</td>
                                                    <td>{items.STARTDATE}</td>
                                                    <td>{items.ENDDATE}</td>
                                                    <td>{items.PAYMENTSTATUS}</td>
                                                </tr>
                                            })
                                        }
                                    </tbody>
                                </table>
                                <div className="d-flex justify-content-center mt-10 mb-10"
                                >
                                    <Pagination
                                        count={Math.ceil(tableData.length / itemsPerPage)}
                                        page={currentPage}
                                        onChange={handlePageChange}
                                        shape="rounded"
                                        showLastButton
                                        showFirstButton
                                        color="primary"
                                        
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/*end::Container*/}
            </div>
            {/*end::Post*/}
        </div>

    );
};

export default MemberShipTransaction;

