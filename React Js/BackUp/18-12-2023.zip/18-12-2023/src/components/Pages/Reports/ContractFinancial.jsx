import React, { useState } from "react";
import Pagination from "@mui/material/Pagination";
import '@emotion/styled';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
const ContractFinancial = () => {
    // const [currentPage, setCurrentPage] = useState(1);
    // const itemsPerPage = 10; // Number of items to display per page

    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10; // 
    const tableData = [
        {
            id: "1",
            date: "27/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "2",
            date: "27/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "3",
            date: "28/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "4",
            date: "28/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "5",
            date: "28/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "6",
            date: "28/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "7",
            date: "27/11/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "8",
            date: "27/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "9",
            date: "27/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "10",
            date: "27/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "11",
            date: "27/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
        {
            id: "12",
            date: "27/10/2023",
            payment_mode: "myfatoorah",
            membership_information: "10 Additional Contract Buy",
            amount: "50",
            payment_status: "Pending",
        },
    ]
    // // Logic to paginate the table data
    // const indexOfLastItem = currentPage * itemsPerPage;
    // const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    // const currentItems = tableData.slice(indexOfFirstItem, indexOfLastItem);

    // // Function to handle page change
    // const paginate = (pageNumber) => {
    //     setCurrentPage(pageNumber);
    // };
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = tableData.slice(indexOfFirstItem, indexOfLastItem);

    // Function to handle page change
    const handlePageChange = (event, value) => {
        setCurrentPage(value);
    };
    return (
        <>
            <div
                className="content d-flex flex-column flex-column-fluid pt-0"
                id="kt_content"
            >
                {/*begin::Post*/}
                <div className="post d-flex flex-column-fluid" id="kt_post">
                    {/*begin::Container*/}
                    <div id="kt_content_container" className="container-xxl mt-10">
                        {/*begin::Toolbar*/}
                        <div className="toolbar" id="kt_toolbar">
                            {/*begin::Container*/}
                            <div id="kt_toolbar_container" className="d-flex flex-stack">
                                {/*begin::Page title*/}
                                <div
                                    data-kt-swapper="true"
                                    data-kt-swapper-mode="prepend"
                                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                    className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                >
                                    {/*begin::Title*/}
                                    <h1 className="d-flex align-items-center text-dark fw-bolder px-3 py-3 py-lg-6 fs-3 my-1 ">
                                        Contract Financial Transaction
                                    </h1>
                                    {/*end::Title*/}
                                </div>
                                {/*end::Page title*/}
                            </div>
                            {/*end::Container*/}
                        </div>
                        {/*end::Toolbar*/}
                        <div className="report_otr">
                            {/* <div className="business-panel-tabs mt-5"> */}
                            <div className="card">
                                <div className="card-body">
                                    <div className="d-flex justify-content-md-end flex-wrap">
                                        <div className="mb-0 p-3">
                                            <div className="react-datepicker__input-container">
                                                {/* <input type="text" placeholder="Select start date" className="form-control form-control-solid react-datepicker-ignore-onclickoutside" value="" /> */}
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DatePicker />
                                                </LocalizationProvider>
                                            </div>
                                        </div>
                                        <div className="mb-0 p-3">
                                            <div className="react-datepicker__input-container">
                                                {/* <input type="text" placeholder="Select start date" className="form-control form-control-solid react-datepicker-ignore-onclickoutside" value="" /> */}
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DatePicker />
                                                </LocalizationProvider>
                                            </div>
                                        </div>
                                        <div className="mb-0 p-3">
                                            <button className="btn btn-sm btn-primary">Download</button>
                                        </div>
                                    </div>

                                    <div className="table-responsive ">
                                        <table className="table  table-row-dashed  gy-7 gs-7  ">
                                            <thead>
                                                <tr className=" text-dark-400 fw-bolder fs-7 text-uppercase gs-0">
                                                    <th className="min-w-100px">TRANSACTION ID</th>
                                                    <th className="min-w-100px">TRANSACTION DATE</th>
                                                    <th className="min-w-100px">PAYMENT MODE</th>
                                                    <th className="min-w-100px">MEMBERSHIP INFORMATION</th>
                                                    <th className="min-w-100px">AMOUNT </th>
                                                    <th className="min-w-100px">PAYMENT STATUS</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    currentItems.map((items, index) => {
                                                        return <tr key={index}>
                                                            <td>{items.id}</td>
                                                            <td>{items.date}</td>
                                                            <td>{items.payment_mode}</td>
                                                            <td>{items.membership_information}</td>
                                                            <td>{items.amount}</td>
                                                            <td>{items.payment_status}</td>
                                                        </tr>
                                                    })
                                                }

                                            </tbody>
                                        </table>
                                        {/* <div className="d-flex justify-content-center mt-10 mb-10">
                                                <ul className="pagination">
                                                    <li className="page-item" onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1}>
                                                        <a className="page-link" role="button" tabIndex={0} href="#">
                                                            &lt; 
                                                        </a>
                                                    </li>
                                                    {Array.from({ length: Math.ceil(tableData.length / itemsPerPage) }, (_, i) => (
                                                        <li key={i} className={`page-item ${currentPage === i + 1 ? 'active' : ''}`}>
                                                            <a className="page-link" role="button" tabIndex={0} href="#" onClick={() => paginate(i + 1)}>
                                                                {i + 1}
                                                            </a>
                                                        </li>
                                                    ))}
                                                    <li className="page-item" onClick={() => paginate(currentPage + 1)} disabled={currentPage === Math.ceil(tableData.length / itemsPerPage)}>
                                                        <a className="page-link" role="button" tabIndex={0} href="#">
                                                            &gt;&gt;
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div> */}
                                        <div className="d-flex justify-content-center mt-10 mb-10">
                                            <Pagination
                                                count={Math.ceil(tableData.length / itemsPerPage)}
                                                page={currentPage}
                                                onChange={handlePageChange}
                                                shape="rounded"
                                                showLastButton
                                                showFirstButton
                                                color="primary"
                                            />
                                        </div>

                                    </div>


                                </div>
                            </div>
                            {/* </div> */}
                        </div>
                    </div>
                    {/*end::Container*/}
                </div>
                {/*end::Post*/}
            </div>
        </>
    );
};

export default ContractFinancial;
