import { Pagination } from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import React, { useState } from 'react';

const ExportContractList = () => {

    // pagination state
    const [currentPage, setCurrentPage] = useState(1);
    // number of data that show on one page
    const itemsPerPage = 10;

    const tableData = [
        {
            CONTRACTID: '1',
            CONTRACTCREATEDATE: '30/10/2023',
            CONTRACTSTATUS: 'المرفوضة',
            CONTRACTCATEGORY: 'Ceat',
            CONTRACTTITLE: 'Non-Disclosure and Confidentiality Agreement Between Tothiq - Hisham Ayman Hamed',
            CONTRACTAUTHORIZEDSIGNATORY: '',
            CONTRACTRENEWALDATE: '',
        },
        {
            CONTRACTID: '2',
            CONTRACTCREATEDATE: '20/11/2023',
            CONTRACTSTATUS: 'ready',
            CONTRACTCATEGORY: 'Ceat',
            CONTRACTTITLE: 'Non-Disclosure and Confidentiality Agreement Between Tothiq - Creativ',
            CONTRACTAUTHORIZEDSIGNATORY: '',
            CONTRACTRENEWALDATE: '',
        },
        {
            CONTRACTID: '3',
            CONTRACTCREATEDATE: '05/12/2023',
            CONTRACTSTATUS: 'ready',
            CONTRACTCATEGORY: 'Rent',
            CONTRACTTITLE: '٢- إتفاقية عدم الإفصاح',
            CONTRACTAUTHORIZEDSIGNATORY: '',
            CONTRACTRENEWALDATE: '',
        },
        {
            CONTRACTID: '4',
            CONTRACTCREATEDATE: '05/12/2023',
            CONTRACTSTATUS: 'review',
            CONTRACTCATEGORY: 'Ceat',
            CONTRACTTITLE: 'Contract Status - Check - Contract',
            CONTRACTAUTHORIZEDSIGNATORY: '',
            CONTRACTRENEWALDATE: '',
        },
        {
            CONTRACTID: '5',
            CONTRACTCREATEDATE: '05/12/2023',
            CONTRACTSTATUS: 'rejected',
            CONTRACTCATEGORY: 'Rent',
            CONTRACTTITLE: '١- إتفاقية تأجير شقة',
            CONTRACTAUTHORIZEDSIGNATORY: '',
            CONTRACTRENEWALDATE: '',
        },
        {
            CONTRACTID: '6',
            CONTRACTCREATEDATE: '05/12/2023',
            CONTRACTSTATUS: 'draft',
            CONTRACTCATEGORY: 'Rent',
            CONTRACTTITLE: '-Contract Status - Check - Contract - Lorem Ipsum is',
            CONTRACTAUTHORIZEDSIGNATORY: '',
            CONTRACTRENEWALDATE: '',
        }
    ]

    // pagination functions
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = tableData.slice(indexOfFirstItem, indexOfLastItem);

    // Function to handle page change
    const handlePageChange = (event, value) => {
        setCurrentPage(value);
    };

    return (
        <>
            {/* <div className="mb-20 post d-flex flex-column-fluid">
                <div className="mb-10 container-xxl mt-10">
                    <div className="container-xxl">
                        <div className="app-toolbar py-3 py-lg-6">
                            <div className="app-container px-3 d-flex flex-stack">
                                <div className="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                    <h1 className="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Contract Financial Transaction</h1>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div> */}
            <div
                className="content d-flex flex-column flex-column-fluid pt-0"
                id="kt_content"
            >
                {/*begin::Post*/}
                <div className="post d-flex flex-column-fluid" id="kt_post">
                    {/*begin::Container*/}
                    <div id="kt_content_container" className="container-xxl mt-10">
                        {/*begin::Toolbar*/}
                        <div className="toolbar" id="kt_toolbar">
                            {/*begin::Container*/}
                            <div id="kt_toolbar_container" className="d-flex flex-stack">
                                {/*begin::Page title*/}
                                <div
                                    data-kt-swapper="true"
                                    data-kt-swapper-mode="prepend"
                                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                    className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                >
                                    {/*begin::Title*/}
                                    <h1 className="d-flex align-items-center text-dark fw-bolder fs-3 my-1 px-3 py-3 py-lg-6">
                                        Export Contract List
                                    </h1>
                                    {/*end::Title*/}
                                </div>
                                {/*end::Page title*/}
                            </div>
                            {/*end::Container*/}
                        </div>
                        {/*end::Toolbar*/}
                        <div className="card">
                            <div className="card-body">
                                <div className="d-flex justify-content-md-end flex-wrap ">
                                    <div className="mb-0 p-3">
                                        <div className="react-datepicker-wrapper">
                                            <div className="react-datepicker__input-container">
                                                {/* <input type="date" placeholder="Select start date" className="form-control form-control-solid" /> */}
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DatePicker />
                                                </LocalizationProvider>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mb-0 p-3">
                                        <div className="react-datepicker-wrapper">
                                            <div className="react-datepicker__input-container">
                                                {/* <input type="date" placeholder="Select end date" className="form-control form-control-solid" /> */}
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DatePicker />
                                                </LocalizationProvider>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mb-0 p-3">
                                        <button className="btn btn-sm btn-primary">Download</button>
                                    </div>
                                </div>
                                <div className="table-responsive">
                                    <table className="table table-row-dashed gy-7 gs-7">
                                        <thead>
                                            <tr className="fw-bolder fs-7 text-gray-800 ">
                                                <th className="min-w-100px">CONTRACT ID</th>
                                                <th className="min-w-100px">CONTRACT CREATE DATE</th>
                                                <th className="min-w-100px">CONTRACT STATUS</th>
                                                <th className="min-w-100px">CONTRACT CATEGORY</th>
                                                <th className="min-w-100px">CONTRACT TITLE</th>
                                                <th className="min-w-100px">CONTRACT AUTHORIZED SIGNATORY</th>
                                                <th className="min-w-100px">CONTRACT RENEWAL DATE</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                tableData.map((items, key) => {
                                                    return <tr key={key}>
                                                        <td>{items.CONTRACTID}</td>
                                                        <td>{items.CONTRACTCREATEDATE}</td>
                                                        <td>{items.CONTRACTSTATUS}</td>
                                                        <td>{items.CONTRACTCATEGORY}</td>
                                                        <td>{items.CONTRACTTITLE}</td>
                                                        <td>{items.CONTRACTAUTHORIZEDSIGNATORY}</td>
                                                        <td>{items.CONTRACTRENEWALDATE}</td>
                                                    </tr>
                                                })
                                            }

                                        </tbody>
                                    </table>
                                </div>
                                <div className="d-flex justify-content-center mt-10 mb-10"
                                >
                                    <Pagination
                                        count={Math.ceil(tableData.length / itemsPerPage)}
                                        page={currentPage}
                                        onChange={handlePageChange}
                                        shape="rounded"
                                        showLastButton
                                        showFirstButton
                                        color="primary"

                                    />
                                </div>
                            </div>
                        </div>

                    </div>
                    {/*end::Container*/}
                </div>
                {/*end::Post*/}
            </div>


        </>
    );
};

export default ExportContractList;

