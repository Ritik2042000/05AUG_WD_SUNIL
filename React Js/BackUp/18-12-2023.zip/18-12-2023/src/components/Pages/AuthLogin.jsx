import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router-dom"
import { setUserLogin } from "../../redux/login_user/loginUserSlice";

const AuthLogin = () => {

  const { token, type } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const englishLabels = [
    {
      id: 1,
      label: "Home"
    },
    {
      id: 2,
      lable: "About"
    }
  ]

  const arabicLabels = [
    {
      id: 1,
      label: "بيت"
    },
    {
      id: 2,
      label: "عن"
    }
  ]

  useEffect(() => {
    dispatch(setUserLogin({
      type: type,
      token: token,
      labels:{
        englishLabels:englishLabels,
        arabicLabels:arabicLabels
      }
    }))
    localStorage.setItem("type", JSON.stringify(type))
    localStorage.setItem("token", JSON.stringify(token))
    localStorage.setItem("EnglishLabels", JSON.stringify(englishLabels))
    localStorage.setItem("ArabicLabels", JSON.stringify(arabicLabels))
    navigate("/dashboard")
  }, [])

  return (
    <div>AuthLogin</div>
  )
}

export default AuthLogin