import React, { useEffect, useState } from 'react';
import Template1 from "../../../assets/images/Contract-Templates/cloudTem.jpeg";
import Template2 from "../../../assets/images/Contract-Templates/AffilateTem.jpeg";
import Template3 from "../../../assets/images/Contract-Templates/AppreTem.jpeg";
import Template4 from "../../../assets/images/Contract-Templates/AdvertTem.jpeg";
import Template5 from "../../../assets/images/Contract-Templates/ApiTem.jpeg";
import Template6 from "../../../assets/images/Contract-Templates/confideTem.jpeg";
import Template7 from "../../../assets/images/Contract-Templates/EquityTem.jpeg";
import Template8 from "../../../assets/images/Contract-Templates/PowerTem.jpeg";
import Template9 from "../../../assets/images/Contract-Templates/SalaryTem.jpeg";
import Template10 from "../../../assets/images/Contract-Templates/SeprationTem.jpeg";
import Template11 from "../../../assets/images/Contract-Templates/PurchesTem.jpeg";
import Template12 from "../../../assets/images/Contract-Templates/ReffralTem.jpeg";
import Template13 from "../../../assets/images/Contract-Templates/RecurementTem.jpeg";
import Template14 from "../../../assets/images/Contract-Templates/ShareHolderTem.jpeg";
import Template15 from "../../../assets/images/Contract-Templates/ShareSubTem.jpeg";
import Template16 from "../../../assets/images/Contract-Templates/ServiceTem.jpeg";
import Template17 from "../../../assets/images/Contract-Templates/WarrentyTem.jpeg";
import Template18 from "../../../assets/images/Contract-Templates/StatmentTem.jpeg";
import Template19 from "../../../assets/images/Contract-Templates/VendorTem.jpeg";
import Template20 from "../../../assets/images/Contract-Templates/SupplierTem.jpeg";
import Template21 from "../../../assets/images/Contract-Templates/PrivacyTem.jpeg";
import Template22 from "../../../assets/images/Contract-Templates/TerminationTem.jpeg";
import Template23 from "../../../assets/images/Contract-Templates/PropertyTem.jpeg";
import Template24 from "../../../assets/images/Contract-Templates/AppreTem.jpeg";
// import Template25 from "../../../assets/images/Contract-Templates/AppreTem.jpeg";
import { NavLink } from 'react-router-dom';

const Contract_Step1 = () => {

    const [search, setSearch] = useState("");
    const [searchtemplate, setSearchTemplate] = useState("");

    const [selectedCategory, setSelectedCategory] = useState(0);
    const [filteredTemplates, setFilteredTemplates] = useState([]);
    // console.log(filteredTemplates);

    const handleClick = (categoryId) => {
        setSelectedCategory(categoryId);
    };

    useEffect(() => {
        if (selectedCategory) {
            const filtered = templates.filter(
                (template) => template.categoryId === selectedCategory
            );
            setFilteredTemplates(filtered);
        } else {
            setFilteredTemplates(templates);
        }
    }, [selectedCategory]);


    const categories = [
        { id: 0, name: "All" },
        { id: 1, name: "Availability" },
        { id: 2, name: "Business" },
        { id: 3, name: "Ceat" },
        { id: 4, name: "Consulting" },
        { id: 5, name: "Education" },
        { id: 6, name: "Employment" },
        { id: 7, name: "Healthcare" },
        { id: 8, name: "House" },
        { id: 9, name: "Legal" },
        { id: 10, name: "Loans" },
        { id: 11, name: "Manufacturing" },
        { id: 12, name: "Marketing" },
        { id: 13, name: "Real Estate" },
        { id: 14, name: "Rent" },
        { id: 15, name: "Sell" },
        { id: 16, name: "Software" },
        { id: 17, name: "Technology" },
        { id: 18, name: "Web Development" },
        // { id: 19, name: "Test Titlea" },
    ];

    const templates = [

        {
            id: 0,
            name: "Cloud services agreement template",
            templateImg: <img className='w-100' src={Template1} alt="Template Img" />,
            categoryId: 16,
            type: 'Basic'

        },
        {
            id: 1,
            name: "Affiliate marketing agreement template",
            templateImg: <img className='w-100' src={Template2} alt="Template Img" />,
            categoryId: 12,
            type: 'Elite'

        },
        {
            id: 2,
            name: "Apprenticeship agreement template",
            templateImg: <img className='w-100' src={Template3} alt="Template Img" />,
            categoryId: 6,
            type: 'Elite'
        },
        {
            id: 3,
            name: "Advertising agreement template",
            templateImg: <img className='w-100' src={Template4} alt="Template Img" />,
            categoryId: 2,
            type: 'Basic'
        },
        {
            id: 4,
            name: "API license agreement template",
            templateImg: <img className='w-100' src={Template5} alt="Template Img" />,
            categoryId: 18,
            type: 'Elite'
        },
        {
            id: 5,
            name: "Confidentiality agreement template",
            templateImg: <img className='w-100' src={Template6} alt="Template Img" />,
            categoryId: 9,
            type: 'Elite'
        },
        {
            id: 6,
            name: "Equity agreement template",
            templateImg: <img className='w-100' src={Template7} alt="Template Img" />,
            categoryId: 13,
            type: 'Elite'
        },
        {
            id: 7,
            name: "Power of attorney template",
            templateImg: <img className='w-100' src={Template8} alt="Template Img" />,
            categoryId: 5,
            type: 'Elite'
        },
        {
            id: 8,
            name: "Salary increase letter template",
            templateImg: <img className='w-100' src={Template9} alt="Template Img" />,
            categoryId: 2,
            type: 'Elite'
        },
        {
            id: 9,
            name: "Separation agreement template",
            templateImg: <img className='w-100' src={Template10} alt="Template Img" />,
            categoryId: 9,
            type: 'Basic'
        },
        {
            id: 10,
            name: "Purchase Order (PO) template",
            templateImg: <img className='w-100' src={Template11} alt="Template Img" />,
            categoryId: 11,
            type: 'Elite'
        },
        {
            id: 11,
            name: "Referral agreement template",
            templateImg: <img className='w-100' src={Template12} alt="Template Img" />,
            categoryId: 9,
            type: 'Elite'
        },
        {
            id: 12,
            name: "Recruitment agreement template",
            templateImg: <img className='w-100' src={Template13} alt="Template Img" />,
            categoryId: 1,
            type: 'Free'
        },
        {
            id: 13,
            name: "Shareholder resolution template",
            templateImg: <img className='w-100' src={Template14} alt="Template Img" />,
            categoryId: 2,
            type: 'Elite'
        },
        {
            id: 14,
            name: "Share Subscription Agreement (SSA) template",
            templateImg: <img className='w-100' src={Template15} alt="Template Img" />,
            categoryId: 2,
            type: 'Elite'
        },
        {
            id: 15,
            name: "Service agreement template",
            templateImg: <img className='w-100' src={Template16} alt="Template Img" />,
            categoryId: 2,
            type: 'Basic'
        },
        {
            id: 16,
            name: "Warranty agreement template",
            templateImg: <img className='w-100' src={Template17} alt="Template Img" />,
            categoryId: 4,
            type: 'Basic'
        },
        {
            id: 17,
            name: "Statement of Work (SOW) template",
            templateImg: <img className='w-100' src={Template18} alt="Template Img" />,
            categoryId: 3,
            type: 'Free'
        },
        {
            id: 18,
            name: "Vendor agreement template",
            templateImg: <img className='w-100' src={Template19} alt="Template Img" />,
            categoryId: 5,
            type: 'Basic'
        },
        {
            id: 19,
            name: "Supplier agreement template",
            templateImg: <img className='w-100' src={Template20} alt="Template Img" />,
            categoryId: 3,
            type: 'Basic'
        },
        {
            id: 20,
            name: "Privacy policy template",
            templateImg: <img className='w-100' src={Template21} alt="Template Img" />,
            categoryId: 11,
            type: 'Basic'
        },
        {
            id: 21,
            name: "Termination agreement template",
            templateImg: <img className='w-100' src={Template22} alt="Template Img" />,
            categoryId: 4,
            type: 'Elite'
        },
        {
            id: 22,
            name: "Property management agreement template",
            templateImg: <img className='w-100' src={Template23} alt="Template Img" />,
            categoryId: 10,
            type: 'Elite'
        },
        {
            id: 23,
            name: "Renting Office Template",
            templateImg: <img className='w-100' src={Template24} alt="Template Img" />,
            // categoryId: 2,
            type: 'Free'
        },
        // {
        //     id: 24,
        //     name: "API licence agreement template",
        //     templateImg: <img className='w-100' src={Template25} alt="Template Img" />,
        //     categoryId: 18,
        //     type: 'Elite'
        // }
    ];



    return (
        <>
            <div className="mb-20 post flex-column-fluid">
                <div className="mb-10  ">
                    <div>
                        <div className="d-flex justify-content-end my-5">
                           
                            <div className="">
                                {/* <div className="mb-2">
                                    <span className="bg-warning bg-opacity-50 text-bolder text-danger text-center">For basic and premium members</span>
                                </div>
                                <div className="create_cont_btn_inr d-flex">
                                    <div className=" me-5">
                                        <button className="btn btn-sm btn-primary">Create Blank Contract</button>
                                    </div>
                                    <div className="">
                                        <button className="btn btn-sm btn-primary">Upload Document</button>
                                    </div>
                                </div> */}
                            </div>
                        </div>
                        <div className="tab-content" id="myTabContent">
                            <div className="tab-pane fade active show" id="all_contracts" role="tabpanel">
                                <div className="row">
                                    <div className="col-lg-3 ">
                                        <div className="card mb-xl-8">
                                            <div className="card-header p-0 min-h-0 m-5 mt-8">
                                                <div className="w-100 mb-5 mb-lg-0 position-relative" autocomplete="off">
                                                    <form data-kt-search-element="form" className=" d-lg-block w-100 mb-lg-0 position-relative" autocomplete="off">
                                                        <span className="svg-icon svg-icon-2 svg-icon-gray-700 position-absolute top-50 translate-middle-y ms-4">
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                                                <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor">
                                                                </path>
                                                            </svg>
                                                        </span>
                                                        <input className="form-control form-control-solid h-40px bg-body ps-13 fs-7" type="text" id="filter" placeholder="Search Categories" onChange={(e) => {
                                                            setSearch(e.target.value);
                                                        }} />
                                                    </form>
                                                </div>
                                            </div>
                                            <div className="card-body p-0 mb-15 contract_tab">
                                                <ul className="nav  flex-row  mb-3 mb-md-0">

                                                    {categories
                                                        .filter((category) => {
                                                            if (search === "") {
                                                                return category;
                                                            } else if (
                                                                category.name
                                                                    .toLowerCase()
                                                                    .includes(search.toLowerCase())
                                                            ) {
                                                                return category;
                                                            }
                                                        })
                                                        .map((category) => {
                                                            return (
                                                                <li
                                                                    onClick={() => handleClick(category.id)}
                                                                    className={`d-block w-100 text-center text-md-start fs-6 fw-bold nav-link text-active-primary border-active-primary  border-2 text-dark pointer contract_temp_navlist ${selectedCategory === category.id
                                                                        ? "selected"
                                                                        : ""
                                                                        }`}
                                                                    key={category.id}
                                                                >
                                                                    {category.name}
                                                                </li>
                                                            );
                                                        })}

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="card col-lg-9 ">
                                        <div className="card-body tab-content" id="myTabContent">
                                            <div className="card-header border-0 p-0 min-h-0">
                                                <div className="w-100 mb-5 mb-lg-0 position-relative" autocomplete="off">
                                                    <form data-kt-search-element="form" className="d-lg-block w-100 mb-lg-0 position-relative" autocomplete="off">
                                                        <span className="svg-icon svg-icon-2 svg-icon-gray-700 position-absolute top-50 translate-middle-y ms-4">
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor">
                                                                </rect>
                                                                <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor">
                                                                </path>
                                                            </svg>
                                                        </span>
                                                        <input className="form-control form-control-solid h-40px bg-body ps-13 fs-7" type="text" id="filter" placeholder="Search Templates" onChange={(e) => {
                                                            setSearchTemplate(e.target.value);
                                                        }} />
                                                    </form>
                                                </div>
                                            </div>
                                            {filteredTemplates.length > 0 ? (
                                                <div className="row d-flex flex-wrap">
                                                    {filteredTemplates
                                                        .filter((templates) => templates.name.toLowerCase().includes(searchtemplate.toLowerCase()))
                                                        .filter((template) => template.name !== "All")
                                                        .map((template) => {
                                                            return (
                                                                <div className=" col-12 col-sm-6 col-md-3 col-lg-4 col-xl-3 p-5">
                                                                    <div className="template_img pb-3 position-relative" key={template.id}>
                                                                        <NavLink to="">
                                                                            {template.templateImg}
                                                                            <span className="position-absolute top-5 start-0 m-1 text-dark bg-warning bg-opacity-50 ms-2 px-1">{template.type}</span>

                                                                            <p className="template-name pt-1 text-dark text-hover-primary template_lable fs-6 fw-bold">
                                                                                {template.name}
                                                                            </p>
                                                                        </NavLink>
                                                                    </div>
                                                                </div>
                                                            );
                                                        })}
                                                </div>
                                            ) : (
                                                <p>No Templates Available for the Selected Category.</p>
                                            )}

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
            {/* </div > */}

        </>
    );
};

export default Contract_Step1;