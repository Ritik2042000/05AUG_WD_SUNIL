import React from 'react';
import SelectComponents from "../../CommonLayouts/SelectComponents";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';



const selectData = [
    { value: 'Recently Updated', label: 'Recently Updated' },
    { value: 'Last Month', label: 'Last Month' },
    { value: 'Last Quarter', label: 'Last Quarter' },
    { value: 'Last Year', label: 'Last Year' }
]

const Contract_Step2 = () => {
    return (
        <>

            <div className="step2_otr">
                <div className="row">
                    <div className="col-xl-12">
                        <div className="flied pb-6">
                            <label htmlFor="contracttitle" className="form-label-workflow required">
                                Contract Title
                            </label>
                            <input
                                type="text"
                                className="form-control form-control-lg"
                                id="contracttitle"
                                placeholder="Enter Contract Title"
                            />
                        </div>
                    </div>
                    {/* <div className="row"> */}
                    <div className="col-xl-6 col-lg-6 col-md-4">
                        <div className="flied pb-6">
                            <label htmlFor="name" className="form-label-workflow required">
                                Workflow Name
                            </label>
                            <SelectComponents Options={selectData} />
                        </div>
                    </div>
                    <div className="col-xl-6 col-lg-6 col-md-4">
                        <div className="flied pb-6">
                            <label htmlFor="name" className="form-label-workflow required">
                                Workflow Name
                            </label>
                            <SelectComponents Options={selectData} />
                        </div>
                    </div>
                    {/* </div> */}
                    <div className="col-xl-12">
                        <div className="text_description pb-6">
                            <label htmlFor="exampleFormControlTextarea1" className="form-label"> Description</label>
                            <textarea className="form-control" id="exampleFormControlTextarea1" rows={3} defaultValue={""} style={{ height: "250px" }} />
                        </div>
                    </div>
                    <div className="row ">
                        <div className="check_box d-flex">
                            <input className="form-check-input " type="checkbox" id="checkboxNoLabel" defaultValue aria-label="..." />
                            <label htmlFor="name" className="form-label-workflow required">
                                Duration Date
                            </label>
                        </div>
                        <div className="col-xl-3 col-lg-4 col-md-4">
                            <div className="flied pb-6">
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                    <DatePicker />
                                </LocalizationProvider>
                            </div>
                        </div>
                        <div className="col-xl-3 col-lg-4 col-md-4">
                            <div className="flied pb-6">
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                    <DatePicker />
                                </LocalizationProvider>
                            </div>
                        </div>
                    </div>
                    <div className="row ">
                        <div className="check_box d-flex">
                            <input className="form-check-input " type="checkbox" id="checkboxNoLabel" defaultValue aria-label="..." />
                            <label htmlFor="name" className="form-label-workflow required">
                                Contract Fees
                            </label>
                        </div>
                        <div className="col-xl-3 col-lg-4 col-md-4">
                            <div className="flied pb-6">
                                <label htmlFor="name" className="form-label-workflow required">
                                    Currency
                                </label>
                                <SelectComponents Options={selectData} />
                            </div>
                        </div>
                        <div className="col-xl-3 col-lg-4 col-md-4">
                            <div className="flied pb-6">
                                <label htmlFor="contractamount" className="form-label-workflow required">
                                    Contract Amount
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    id="contractamount"
                                />
                            </div>
                        </div>
                        <div className="col-xl-3 col-lg-4 col-md-4">
                            <div className="flied pb-6">
                                <label htmlFor="contractwords" className="form-label-workflow required">
                                    Contract Amount in Words
                                </label>
                                <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    id="contractwords"
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bottom_content row">
                    <div className="col-xl-12">
                        <div className="flied pb-6">
                            <div className="check_box d-flex">
                                <input className="form-check-input" type="checkbox" id="checkboxNoLabel" defaultValue aria-label="..." />
                                <label htmlFor="name" className="form-label-workflow required">
                                    Court jurisdiction Clause
                                </label>
                            </div>
                            <div className="para">
                                <p>The Parties irrevocably agree that the courts of Kuwait shall have exclusive jurisdiction to settle any dispute or claim (including non-contractual disputes or claims) arising out of or in ceeding upon any such dispute e or claim except in such courts. tto commence any suit, action or proceeding The Parties agree not connection with this Agreement or its subject matter or formation. The Parties agree Notwithstanding the preceding sentences, nothing in this proceedings is clause shall limit the right of (Company Name) to take proceedi Lagainst any Party in any other court of competent jurisdiction.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-12">
                        <div className="flied pb-6">
                            <div className="check_box d-flex">
                                <input className="form-check-input" type="checkbox" id="checkboxNoLabel" defaultValue aria-label="..." />
                                <label htmlFor="name" className="form-label-workflow required">
                                    Court Arbitration Clause
                                </label>
                            </div>
                            <div className="para">
                                <p>All disputes, controversies, or claims (including non-contractual disputes or claims) arising out of or in connection with this agreement, including its interpretation, validity, subject matter or termination, shall be finally settled under the Rules of Arbitration of the Kuwait International Arbitration Centre by one or more re arbitrators arbitrators appointed appointe in accordance with said Rules. The place of arbitration shall be Kuwait City, Kuwait. The language to be used in the arbitration proceedings shall Arabic. The arbitral award shall be final, binding and non-appealabile.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    );
};

export default Contract_Step2;






