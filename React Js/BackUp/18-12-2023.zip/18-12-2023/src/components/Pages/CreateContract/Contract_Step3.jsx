import React from 'react'

const Contract_Step3 = () => {
    return (
        <div >

            <div className='first_parties_otr'>
                <div className='card'>
                    <div className='card-body'>
                        <div className='heading_parties'>
                            <h1 className='mb-3'>First Parties</h1>
                        </div>
                        <div className='d-flex flex-wrap'>
                            <div className='p-5 ps-0 col-xl-3 col-lg-4 col-md-4 col-sm-4 col-12'>
                                <label className='form-label fs-6 fw-bolder text-dark'>Civil ID</label>
                                <input type='text' className='form-control form-control-white border-secondary'></input>
                            </div>
                            <div className='fv-row py-5 col-xl-3 col-lg-4 col-md-4 col-sm-4 col-12'>
                                <label className='form-label fs-6 fw-bolder text-dark'>Name</label>
                                <input type='text' className='form-control form-control-white border-secondary'></input>
                            </div>
                            <div className='fv-row p-5 col-xl-3 col-lg-4 col-md-4 col-sm-4 col-12'>
                                <label className='form-label fs-6 fw-bolder text-dark'>Email</label>
                                <input type='text' className='form-control form-control-white border-secondary'></input>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='second_parties_otr mt-5'>
                <div className='card'>
                    <div className='card-body'>
                        <div className='heading_parties'>
                            <h1 className='mb-3'>Second Parties</h1>
                        </div>
                        <div className='d-flex flex-wrap'>
                            <div className='p-5 ps-0 col-xl-3 col-lg-4 col-md-4 col-sm-4 col-12'>
                                <label className='form-label fs-6 fw-bolder text-dark'>Civil ID</label>
                                <input type='text' className='form-control form-control-white border-secondary'></input>
                            </div>
                            <div className='fv-row py-5 col-xl-3 col-lg-4 col-md-4 col-sm-4 col-12'>
                                <label className='form-label fs-6 fw-bolder text-dark'>Name</label>
                                <input type='text' className='form-control form-control-white border-secondary'></input>
                            </div>
                            <div className='fv-row p-5 col-xl-3 col-lg-4 col-md-4 col-sm-4 col-12'>
                                <label className='form-label fs-6 fw-bolder text-dark'>Email</label>
                                <input type='text' className='form-control form-control-white border-secondary'></input>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div classname="upgrade_membership_otr">
                <div classname="upgrade_membership_inr">
                    <div className="membership_box border border-primary my-20 p-10">
                        <div className="d-flex pt-3 justify-content-between">
                            <h2>Would you like to add more parties?</h2>
                            <button className="upgrade_membership btn btn-sm">Upgrade Membership</button>
                        </div>
                    </div>
                </div>
            </div>




        </div>
    )
}

export default Contract_Step3