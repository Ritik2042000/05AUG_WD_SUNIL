import React, { useState } from 'react';
import BusinessProfileImg from "../../../assets/images/business_profile.jpeg";
import UserProfile from "../../../assets/images/User_Profile.jpeg";
import UserImg from "../../../assets/images/User_Img.jpeg";
import Tothiq from "../../../assets/images/tothiq_logo.png"

const AddressContent = () => {
    const [activeTab, setActiveTab] = useState('userTab');

    const handleTabChange = (tabId) => {
        setActiveTab(tabId);
    };
    return (
        <div className='row my-5'>
            <div className='col-xl-3 col-lg-3'>
                <div className='card h-100'>
                    <div className='card-body p-0'>
                        <div className='address_book_content_one'>
                            <ul className='nav nav-tabs nav-line-tabs mb-5 fs-6 mx-10'>
                                <li className='nav-item me-0'>
                                    <a
                                        className={`fs-6 fw-bold nav-link ${activeTab === 'userTab' ? 'active text-active-primary border-active-primary border-2 text-dark' : 'text-active-primary border-active-primary border-2 text-dark'}`}
                                        data-bs-toggle='tab'
                                        href='#userTab'
                                        onClick={() => handleTabChange('userTab')}
                                    >
                                        Users
                                    </a>
                                </li>
                                <li className='nav-item me-0'>
                                    <a
                                        className={`fs-6 fw-bold nav-link ${activeTab === 'inviteeTab' ? 'active text-active-primary border-active-primary border-2 text-dark' : 'text-active-primary border-active-primary border-2 text-dark'}`}
                                        data-bs-toggle='tab'
                                        href='#inviteeTab'
                                        onClick={() => handleTabChange('inviteeTab')}
                                    >
                                        Invitees
                                    </a>
                                </li>
                            </ul>
                            <div className='tab-content' id='myTabContentUsersInvitees'>
                                <div
                                    className='tab-pane fade show active'
                                    id='userTab'
                                    role='tabpanel'
                                >
                                    <div className='user_list'>
                                        <ul className='Addresscontent nav flex-row flex-md-column mb-3 mb-md-0'>
                                            <li className='nav-item me-0'>
                                                <a className='fs-6 fw-bold nav-link text-active-primary border-active-primary border-start border-2 text-dark active' data-bs-toggle="tab" href='#darshanTab'>
                                                    <img src={BusinessProfileImg} className='profile_img me-3' alt='Business Profile' />
                                                    Darshan Patoliya
                                                </a>
                                            </li>
                                            <div className='my-1'></div>
                                            <li className='nav-item me-0'>
                                                <a className='fs-6 fw-bold nav-link text-active-primary border-active-primary border-start border-2 text-dark' data-bs-toggle="tab" href='#jackTab'>
                                                    <img src={BusinessProfileImg} className='profile_img me-3' alt='Business Profile' />
                                                    Jack Mackwan
                                                </a>
                                            </li>
                                            <div className='my-1'></div>
                                        </ul>
                                    </div>
                                </div>
                                <div
                                    className='tab-pane fade'
                                    id='inviteeTab'
                                    role='tabpanel'
                                >
                                    <div className='invitees'>
                                        <ul className='contract_tab nav flex-row flex-md-column mb-3 mb-md-0'>
                                            <li className='nav-item me-0'>
                                                <a className='fs-6 fw-bold nav-link text-active-primary border-active-primary border-start border-2 text-dark active' data-bs-toggle="tab" href='#faisalTab'>
                                                    <img src={BusinessProfileImg} className='profile_img me-3' alt='Business Profile' />
                                                    faisal@wavai.com
                                                </a>
                                            </li>
                                            <div className='my-1'></div>
                                            {/* Add other invitees as needed */}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='col-xl-9 col-lg-9 px-0 mt-0 addresbook_contact-detalis'>
                <div className='tab-content' id='myTabContentDetailsContracts'>
                    {activeTab === 'userTab' && (
                        <>
                            <div
                                className='tab-pane fade show active'
                                id='darshanTab'
                                role='tabpanel'
                            >
                                <div className='d-flex flex-wrap card'>
                                    <div className='p-4 mb-3 align-items-center'>
                                        <h2 className='text-primary'>Contact Details</h2>
                                    </div>
                                    <div className='user_info_otr d-flex pb-5'>
                                        <div className='user_profile mx-9'>
                                            <div className='user_img'>
                                                <img src={UserProfile} className='border'></img>
                                            </div>
                                        </div>
                                        <div className='user_details'>
                                            <h3 className='mb-5'>Darshan Patoliya</h3>
                                            <p className='fs-6 fw-normal'>
                                                <svg className='me-5 text_user' xmlns="http://www.w3.org/2000/svg" height={16} width={16} viewBox="0 0 512 512"><path d="M215.4 96H144 107.8 96v8.8V144v40.4 89L.2 202.5c1.6-18.1 10.9-34.9 25.7-45.8L48 140.3V96c0-26.5 21.5-48 48-48h76.6l49.9-36.9C232.2 3.9 243.9 0 256 0s23.8 3.9 33.5 11L339.4 48H416c26.5 0 48 21.5 48 48v44.3l22.1 16.4c14.8 10.9 24.1 27.7 25.7 45.8L416 273.4v-89V144 104.8 96H404.2 368 296.6 215.4zM0 448V242.1L217.6 403.3c11.1 8.2 24.6 12.7 38.4 12.7s27.3-4.4 38.4-12.7L512 242.1V448v0c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64v0zM176 160H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H176c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H176c-8.8 0-16-7.2-16-16s7.2-16 16-16z" /></svg>
                                                darshan@mailinator.com</p>
                                            <p className='fs-6 fw-normal'>
                                                <svg className='me-5 text_user' xmlns="http://www.w3.org/2000/svg" height={16} width={12} viewBox="0 0 384 512"><path d="M16 64C16 28.7 44.7 0 80 0H304c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H80c-35.3 0-64-28.7-64-64V64zM224 448a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM304 64H80V384H304V64z" /></svg>
                                                123456789</p>
                                        </div>
                                    </div>

                                    <ul className='nav nav-tabs nav-line-tabs mb-5 fs-6 mx-10'>
                                        <li className='nav-item me-0'>
                                            <a className='fs-6 fw-bold nav-link text-active-primary border-active-primary border-2 text-dark active'
                                                data-bs-toggle='tab'
                                                href='#generalTab'
                                            >
                                                General
                                            </a>
                                        </li>
                                        <li className='nav-item me-0 mx-3'>
                                            <a className='fs-6 fw-bold nav-link text-active-primary border-active-primary border-2 text-dark'
                                                data-bs-toggle='tab'
                                                href='#contractsTab'
                                            >
                                                Contracts
                                            </a>
                                        </li>
                                    </ul>
                                    <div className='tab-content' id='myTabContent'>
                                        <div
                                            className='tab-pane fade show active'
                                            id='generalTab'
                                            role='tabpanel'
                                        >
                                            <div className='user_info d-flex flex-wrap card'>
                                                <div className='mx-15 my-10'>
                                                    <h5 className='pb-0'>Civil Id Number</h5>
                                                    <p className='fs-6 fw-normal pb-7'>*******</p>
                                                    <h5 className='pb-0'>Nationality</h5>
                                                    <p className='fs-6 fw-normal pb-7'>Kwt</p>
                                                    <h5 className='pb-0'>Gender</h5>
                                                    <p className='fs-6 fw-normal pb-7'>Female</p>
                                                    <h5 className='pb-0'>Date Of Birth</h5>
                                                    <p className='fs-6 fw-normal'>*******</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            className='tab-pane fade'
                                            id='contractsTab'
                                            role='tabpanel'
                                        >
                                            <div className='d-flex flex-wrap card'>
                                                <div className='templates_boxsec card'>
                                                    <div className='container mb-5'>
                                                        <div className='card mb-4 me-4 border-secondary border border-2'>
                                                            <div className='row g-0'>
                                                                <div className='col-md-2 cont_block_1 d-flex justify-content-center align-items-center cursor-pointer'>
                                                                    <img src={UserImg} className='user_img rounded-circle'></img>
                                                                </div>
                                                                <div className='col-md-6 cont_block_2'>
                                                                    <div className='card-body p-5'>
                                                                        <div className='card-title fs-5 fw-bolder cursor-pointer'>٢- إتفاقية عدم الإفصاح</div>
                                                                        <p className='card-text mb-0'>Created Date: 05/12/2023</p>
                                                                        <div className='d-flex'>
                                                                            <p className='card-text mb-0'>
                                                                                <small className='text-muted'>
                                                                                    Status : Ready
                                                                                </small>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className='col-md-4 cont_block_3 d-flex align-items-center justify-content-center'>
                                                                    <div className='svg-icon svg-icon-2 d-flex align-items-center'>
                                                                    </div>
                                                                    <div className='ms-2'>
                                                                        <img src={UserImg} className='user_img_round rounded-circle'></img>
                                                                    </div>
                                                                    <div className='ms-2'>
                                                                        <img src={UserProfile} className='user_img_round rounded-circle'></img>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                className='tab-pane fade'
                                id='jackTab'
                                role='tabpanel'
                            >
                                <div className='d-flex flex-wrap card'>
                                    <div className='p-4 mb-3 align-items-center'>
                                        <h2 className='text-primary'>Contact Details</h2>
                                    </div>
                                    <div className='user_info_otr d-flex pb-5'>
                                        <div className='mx-9'>
                                            <div className='user_img'>
                                                <img src={Tothiq} className='border'></img>
                                            </div>
                                        </div>
                                        <div className='user_details'>
                                            <h3 className='mb-5'>Jack Mackwan</h3>
                                            <p className='fs-6 fw-normal'>
                                                <svg className='me-5 text_user' xmlns="http://www.w3.org/2000/svg" height={16} width={16} viewBox="0 0 512 512"><path d="M215.4 96H144 107.8 96v8.8V144v40.4 89L.2 202.5c1.6-18.1 10.9-34.9 25.7-45.8L48 140.3V96c0-26.5 21.5-48 48-48h76.6l49.9-36.9C232.2 3.9 243.9 0 256 0s23.8 3.9 33.5 11L339.4 48H416c26.5 0 48 21.5 48 48v44.3l22.1 16.4c14.8 10.9 24.1 27.7 25.7 45.8L416 273.4v-89V144 104.8 96H404.2 368 296.6 215.4zM0 448V242.1L217.6 403.3c11.1 8.2 24.6 12.7 38.4 12.7s27.3-4.4 38.4-12.7L512 242.1V448v0c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64v0zM176 160H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H176c-8.8 0-16-7.2-16-16s7.2-16 16-16zm0 64H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H176c-8.8 0-16-7.2-16-16s7.2-16 16-16z" /></svg>
                                                jafok45961@undewp.com</p>
                                            <p className='fs-6 fw-normal'>
                                                <svg className='me-5 text_user' xmlns="http://www.w3.org/2000/svg" height={16} width={12} viewBox="0 0 384 512"><path d="M16 64C16 28.7 44.7 0 80 0H304c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H80c-35.3 0-64-28.7-64-64V64zM224 448a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM304 64H80V384H304V64z" /></svg>
                                                123456789</p>
                                        </div>
                                    </div>

                                    <ul className='nav nav-tabs nav-line-tabs mb-5 fs-6 mx-10'>
                                        <li className='nav-item me-0'>
                                            <a className='fs-6 fw-bold nav-link text-active-primary border-active-primary border-2 text-dark active'
                                                data-bs-toggle='tab'
                                                href='#generalTabJack'
                                            >
                                                General
                                            </a>
                                        </li>
                                        <li className='nav-item me-0 mx-3'>
                                            <a className='fs-6 fw-bold nav-link text-active-primary border-active-primary border-2 text-dark'
                                                data-bs-toggle='tab'
                                                href='#contractsTabJack'
                                            >
                                                Contracts
                                            </a>
                                        </li>
                                    </ul>
                                    <div className='tab-content' id='myTabContent'>
                                        <div
                                            className='tab-pane fade show active'
                                            id='generalTabJack'
                                            role='tabpanel'
                                        >
                                            <div className='user_info d-flex flex-wrap card'>
                                                <div className='mx-15 my-10'>
                                                    <h5 className='pb-0'>Civil Id Number</h5>
                                                    <p className='fs-6 fw-normal pb-7'>*******</p>
                                                    <h5 className='pb-0'>Nationality</h5>
                                                    <p className='fs-6 fw-normal pb-7'>Kwt</p>
                                                    <h5 className='pb-0'>Gender</h5>
                                                    <p className='fs-6 fw-normal pb-7'>Female</p>
                                                    <h5 className='pb-0'>Date Of Birth</h5>
                                                    <p className='fs-6 fw-normal'>*******</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            className='tab-pane fade'
                                            id='contractsTabJack'
                                            role='tabpanel'
                                        >
                                            <div className='d-flex flex-wrap card'>
                                                <div className='templates_boxsec card'>
                                                    <div className='container mb-5'>
                                                        <div className='card mb-4 me-4 border-secondary border border-2'>
                                                            <div className='row g-0'>
                                                                <div className='col-md-2 cont_block_1 d-flex justify-content-center align-items-center cursor-pointer'>
                                                                    <img src={UserImg} className='user_img rounded-circle'></img>
                                                                </div>
                                                                <div className='col-md-6 cont_block_2'>
                                                                    <div className='card-body p-5'>
                                                                        <div className='card-title fs-5 fw-bolder cursor-pointer'>٢- إتفاقية عدم الإفصاح</div>
                                                                        <p className='card-text mb-0'>Created Date: 05/12/2023</p>
                                                                        <div className='d-flex'>
                                                                            <p className='card-text mb-0'>
                                                                                <small className='text-muted'>
                                                                                    Status : Ready
                                                                                </small>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className='col-md-4 cont_block_3 d-flex align-items-center justify-content-center'>
                                                                    <div className='svg-icon svg-icon-2 d-flex align-items-center'>
                                                                    </div>
                                                                    <div className='ms-2'>
                                                                        <img src={UserImg} className='user_img_round rounded-circle'></img>
                                                                    </div>
                                                                    <div className='ms-2'>
                                                                        <img src={UserProfile} className='user_img_round rounded-circle'></img>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                    {activeTab === 'inviteeTab' && (
                        <div
                            className='tab-pane fade show active'
                            id='faisalTab'
                            role='tabpanel'
                        >
                            <div className="d-flex flex-wrap card">
                                <div className="row mx-0 mt-3 align-items-center">
                                    <h2 className="text-primary">Invite Details</h2>
                                </div>
                                <div className="card-body">
                                    <div className="card p-4 border-secondary border border-2">
                                        <div className="row align-items-center ms-4">
                                            <div className="col-9">
                                                <h4>faisal@wavai.com</h4>
                                            </div>
                                            <div className="col-3 d-flex justify-content-end">
                                                <a className="text-hover-danger" href="/user/contact-details">
                                                    <i className="fas fa-trash-alt fs-2 text-danger" />
                                                </a>
                                            </div>
                                        </div>
                                        <div className="ms-7 d-flex">
                                            <div className="card-text">
                                                <h6>Invite Date :</h6>
                                            </div>
                                            <div className="ms-2">
                                                <span>02/12/2023</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    )}
                </div>
            </div>
        </div>
    );

};

export default AddressContent;

