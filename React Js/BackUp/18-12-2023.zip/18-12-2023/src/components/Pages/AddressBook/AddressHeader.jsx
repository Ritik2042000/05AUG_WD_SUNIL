import React from 'react'
// import MyVerticallyCenteredModal from './MyVerticallyCenteredModal';
import { redirect, useNavigate } from "react-router-dom";
const AddressHeader = () => {
    // JSX for the modal content
    // const [modalShow, setModalShow] = React.useState(false);
    // const [modalShowinvitees, setModalShowinvitees] = React.useState(false);

    const navigate = useNavigate();
    const redirect = () => {
        navigate('/addressbook')
    }


    const modalContentinvitees = (
        <div className="invites_popup">
            <div className="popup_content_inr py-lg-10 px-lg-10">
                <div className="d-flex align-items-center justify-content-between">
                    <div className="col-6">
                        <div span={12} className="col">
                            <label className="font-english fs-6 fw-bolder text-dark required form-label">Email</label>
                            <input name="email" type="email" pattern minLength maxLength className="form-control" placeholder="Enter email" />
                        </div>
                    </div>
                    <div className="mt-5">
                        <button className="invite_btn btn btn-sm btn-primary" type="button" onClick={redirect} >Invite Contact</button>
                    </div>
                </div>
            </div>
        </div>

    );


    return (
        <>
            <div className='address_otr'>
                <div className='card'>
                    <div className='d-flex m-0 py-3 flex-wrap'>
                        <div className='header_inr_one  col-xl-5 col-lg-3 col-sm-3 col-3 '>
                        </div>
                        <div className='header_inr_second  col-xl-7 col-lg-9 col-sm-9 col-9 d-flex justify-content-end'>
                            <div className=''>
                                <span className="search_icon svg-icon svg-icon-2 svg-icon-gray-700 position-absolute top-50 translate-middle-y ms-4"><svg width={24} height={24} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height={2} rx={1} transform="rotate(45 17.0365 15.1223)" fill="currentColor" /><path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor" /></svg></span>

                                <input type="text" id="filter" className="form-control form-control-solid h-40px bg-body ps-13 fs-7 w-100" placeholder="Search Contact" />

                            </div>
                            <div className='address_book_btn gap-2 gap-lg-3 ms-5 d-flex align-items-center'>
                                <button
                                    className="btn btn-sm btn-primary"
                                    data-bs-toggle="modal" data-bs-target="#CreateContact">
                                    Create Contact
                                </button>
                            </div>
                            <div className='address_book_btn gap-2 gap-lg-3 ms-5 d-flex align-items-center'>
                                <button
                                    className="btn btn-primary btn-sm"
                                    data-bs-toggle="modal" data-bs-target="#InviteContact"
                                >
                                    Invite Contact
                                </button>
                            </div>
                        </div>

                    </div>

                </div>


            </div>

            {/* create Contact Pop-up */}
            <div className="modal fade" id="CreateContact" tabindex="-1" role="dialog" aria-labelledby="CreateContactTitle" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered modal-lg">
                    <div className="modal-content ">
                        <div className="modal-body">
                            <div className="modal-header">
                                <div className="d-flex align-items-center justify-content-between">
                                    <h2>Create Contact</h2>
                                </div>

                                <button type="button" className="btn-close" aria-label="close" data-bs-dismiss="modal">
                                </button>
                            </div>
                            <div className="modal-body py-lg-10 px-lg-10">
                                <form autoComplete="off">
                                    <div className="row  mb-10">
                                        <div className="col-6">
                                            <div className="col">
                                                <label className=" fs-6 fw-bolder text-dark required form-label">Civil ID</label>
                                                <input name="civil_id" type="number" className="form-control" placeholder="Enter Civil ID Number" />
                                            </div>
                                        </div>
                                        <div className="col-6">
                                            <div className="col">
                                                <label className=" fs-6 fw-bolder text-dark required form-label">Email</label>
                                                <input name="email" type="email" className="form-control" placeholder="Enter email" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="d-flex justify-content-end">
                                        <button className="btn btn-sm btn-primary" type="button">Add Contact</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Invite Contact Pop-up */}
            <div className="modal fade" id="InviteContact" tabindex="-1" role="dialog" aria-labelledby="InviteContactTitle" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered modal-lg">
                    <div className="modal-content ">
                        <div className="modal-body">

                            <div className="modal-header">
                                <div className="d-flex align-items-center justify-content-between">
                                    <h2>Invite Contact</h2>
                                </div>

                                <button type="button" className="btn-close" aria-label="close" data-bs-dismiss="modal">
                                </button>
                            </div>
                            <div className="modal-body py-lg-10 px-lg-10">
                                <div className="invites_popup ">
                                    <div className="popup_content_inr  px-lg-5">
                                        <form action="" >
                                            <div className="d-flex align-items-center justify-content-between">
                                                <div className="col-6">
                                                    <div className="col-12">
                                                        <label className="font-english fs-6 fw-bolder text-dark required form-label">Email</label>
                                                        <input name="email" type="email" className="form-control" placeholder="Enter email" />
                                                    </div>
                                                </div>
                                                <div className="mt-5">
                                                    <button className="invite_btn btn btn-sm btn-primary" type="button"  >Invite Contact</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddressHeader