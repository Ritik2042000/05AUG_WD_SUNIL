import React from 'react'
import AddressHeader from './AddressHeader'
import AddressContent from './AddressContent'

const AddressBook = () => {
    return (
        <div >
            <div
                className="content d-flex flex-column flex-column-fluid pt-0"
                id="kt_content"
            >
                {/*begin::Post*/}
                <div className="post d-flex flex-column-fluid" id="kt_post">
                    {/*begin::Container*/}
                    <div id="kt_content_container" className="container-xxl mt-10">
                        {/*begin::Toolbar*/}
                        <div className="toolbar" id="kt_toolbar">
                            {/*begin::Container*/}
                            <div id="kt_toolbar_container" className="d-flex flex-stack">
                                {/*begin::Page title*/}
                                <div
                                    data-kt-swapper="true"
                                    data-kt-swapper-mode="prepend"
                                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                    className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                >
                                    {/*begin::Title*/}
                                    <h1 className="d-flex align-items-center text-dark fw-bolder fs-3 my-1 pb-4">
                                        Address Book
                                    </h1>
                                    {/*end::Title*/}
                                </div>
                                {/*end::Page title*/}
                            </div>
                            {/*end::Container*/}
                        </div>
                        {/*end::Toolbar*/}
                        <div className=''>
                            <AddressHeader />
                        </div>
                        <div className=''>
                            <AddressContent />
                        </div>
                    </div>
                    {/*end::Container*/}
                </div>
                {/*end::Post*/}
            </div>
        </div>
    )
}

export default AddressBook