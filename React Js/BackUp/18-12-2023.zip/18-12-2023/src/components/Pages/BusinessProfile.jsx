import React, { useRef, useState } from "react";
import BusinessProfileImg from "../../assets/images/business_profile.jpeg";

const BusinessProfile = () => {
  const [businessImg, setBusinessImg] = useState("");
  const [licenseImg, setLicenseImg] = useState("");
  const [signatoryImg, setSignatoryImg] = useState("");

  const businessImgRef = useRef(null);
  const licenseImgRef = useRef(null);
  const signatoryImgRef = useRef(null);

  // business profile upload
  const businessImgClick = () => {
    businessImgRef.current.click();
  };

  const businessImgChange = (event) => {
    setBusinessImg(event.target.files[0]);
  };

  // license copy upload
  const licenseImgClick = () => {
    licenseImgRef.current.click();
  };

  const licenseImgChange = (event) => {
    setLicenseImg(event.target.files[0]);
  };

  // Authorized Signatory upload
  const signatoryImgClick = () => {
    signatoryImgRef.current.click();
  };

  const signatoryImgChange = (event) => {
    setSignatoryImg(event.target.files[0]);
  };

  return (
    <>
      <div className="business-profile">
        <div className="card mb-10">
          <div className="card-body">
            <div className="business-profile-header d-flex justify-content-between align-items-center mb-10">
              <h2 className="text-dark fs-3 fw-bolder">Business Information</h2>
              <button className="btn btn-primary">Save</button>
            </div>

            <div className="row">
              <div className="col-10">
                <div className="d-flex flex-wrap">
                  <div className="p-3 ps-0 col-xl-4">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      Company Name
                    </label>
                    <input
                      name="business_name"
                      type="text"
                      className="form-control form-control"
                      readOnly=""
                      defaultValue="Frontier Technologies"
                    />
                  </div>
                  <div className="p-3 col-xl-4 text-end">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      إسم الشركة
                    </label>
                    <input
                      name="business_name_arabic"
                      type="text"
                      className="form-control text-end"
                    />
                  </div>
                  <div className="p-3 col-xl-4">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      Company Email
                    </label>
                    <input
                      name="business_email_address"
                      type="text"
                      className="form-control form-control"
                      readOnly=""
                      defaultValue="dummy@frontiertechno.com"
                    />
                  </div>
                </div>
                <div className="d-flex flex-wrap mt-2">
                  <div className="p-1 ps-0 col-3">
                    <label className="fs-6 fw-bolder text-dark my-2">
                      Phone Number
                    </label>
                    <div className=" react-tel-input form-control p-0">
                      <div className="special-label">Phone</div>
                      <input
                        className="form-control form-control h-100 w-100"
                        placeholder="1 (702) 123-4567"
                        type="tel"
                      />
                      <div className="flag-dropdown ">
                        <div
                          className="selected-flag"
                          title=""
                          tabIndex={0}
                          role="button"
                          aria-haspopup="listbox"
                        >
                          <div className="flag 0">
                            <div className="arrow" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="fv-plugins-message-container invalid-feedback">
                      <div
                        className="fw-bolder ng-star-inserted"
                        data-field="phone_number"
                        data-validator="notEmpty"
                      />
                    </div>
                  </div>
                  <div className="p-3 col-2">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      Ext. Number
                    </label>
                    <input
                      name="extension_number"
                      type="text"
                      className="form-control"
                    />
                  </div>
                  <div className="p-3 ps-0 col-3">
                    <label className="form-label fs-6 fw-bolder text-dark form-label">
                      Licence Expiry Date
                    </label>
                    <div className="react-datepicker-wrapper">
                      <div className="react-datepicker__input-container">
                        <input
                          type="date"
                          name="licence_expiry_date"
                          className="form-control"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="p-3 col-4">
                    <label className="form-label fs-6 fw-bolder text-dark form-label">
                      Authorized Signatory Expiry Date
                    </label>
                    <div className="react-datepicker-wrapper">
                      <div className="react-datepicker__input-container">
                        <input
                          type="date"
                          name="authorized_signatory_expiry_date"
                          className="form-control"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="d-flex flex-wrap mt-2">
                  <div className="py-3 pe-2 col-6">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      Area
                    </label>
                    <input name="area" type="text" className="form-control" />
                  </div>
                  <div className="py-3 pe-2 col-6 text-end">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      المنطقة
                    </label>
                    <input
                      name="area_arabic"
                      type="text"
                      className="form-control text-end"
                    />
                  </div>
                </div>
                <div className="d-flex flex-wrap mt-2">
                  <div className="py-3 pe-2 col-6">
                    <label className="fs-6 fw-bolder text-dark required form-label">
                      Block
                    </label>
                    <input
                      name="block"
                      type="number"
                      className="form-control"
                    />
                  </div>
                  <div className="py-3 pe-2 col-6 text-end">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      قطعة
                    </label>
                    <input
                      name="block_arabic"
                      type="text"
                      className="form-control text-end"
                    />
                  </div>
                </div>
                <div className="d-flex flex-wrap mt-2">
                  <div className="py-3 pe-2 col-6">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      Street Name/Number
                    </label>
                    <input
                      name="street_name_number"
                      type="text"
                      className="form-control"
                    />
                  </div>
                  <div className="py-3 pe-2 col-6 text-end">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      اسم الشارع/الرقم
                    </label>
                    <input
                      name="street_name_arabic"
                      type="text"
                      className="form-control text-end"
                    />
                  </div>
                </div>
                <div className="d-flex flex-wrap mt-2">
                  <div className="py-3 pe-2 col-6">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      Building Name/Number
                    </label>
                    <input
                      name="building_name_number"
                      type="text"
                      className="form-control"
                    />
                  </div>
                  <div className="py-3 pe-2 col-6 text-end">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      إسم/رقم المبنى
                    </label>
                    <input
                      name="building_name_arabic"
                      type="text"
                      className="form-control text-end"
                    />
                  </div>
                </div>
                <div className="d-flex flex-wrap mt-2">
                  <div className="py-3 pe-2 col-6">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      Office Number
                    </label>
                    <input
                      name="office_number"
                      type="number"
                      className="form-control"
                    />
                  </div>
                  <div className="py-3 pe-2 col-6 text-end">
                    <label className="fs-6 fw-bolder text-dark form-label">
                      رقم المكتب
                    </label>
                    <input
                      name="office_number_arabic"
                      type="text"
                      className="form-control text-end"
                    />
                  </div>
                </div>
              </div>
              <div className="col-2">
                <div className="d-flex justify-content-end flex-wrap">
                  <div className="image-input image-input-outline w-100 d-flex justify-content-end">
                    <div className="w-150px h-150px">
                      {businessImg ? (
                        <img
                          src={URL.createObjectURL(businessImg)}
                          alt="Business Profile Img"
                          className="cursor-pointer w-150px h-150px border border-2 border-secondary"
                        />
                      ) : (
                        <img
                          src={BusinessProfileImg}
                          alt="Business Profile Img"
                          onClick={businessImgClick}
                          className="cursor-pointer w-150px h-150px border border-2 border-secondary"
                        />
                      )}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      ref={businessImgRef}
                      onChange={businessImgChange}
                      className="inputImg"
                    />
                  </div>
                  <button
                    className="btn btn-primary mt-7 btn-sm"
                    onClick={businessImgClick}
                  >
                    Upload Logo
                  </button>
                </div>
              </div>
            </div>

            <h2 className="text-dark fs-3 fw-bolder my-10">
              Business Registration Document
            </h2>
            <div className="row">
              <div className="col-6">
                <h2 className="text-dark fs-3 fw-bolder mb-5">License Copy</h2>
                <div className="register-document">
                  {licenseImg ? (
                    <img
                      src={URL.createObjectURL(licenseImg)}
                      alt="License copy Img"
                      className="cursor-pointer document-img border border-2 border-secondary"
                    />
                  ) : (
                    <h4
                      onClick={licenseImgClick}
                      className="cursor-pointer mb-0 document-img border border-2 border-secondary d-flex justify-content-center align-items-center"
                    >
                      No Image
                    </h4>
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*"
                  ref={licenseImgRef}
                  onChange={licenseImgChange}
                  className="inputImg"
                />
                <button
                  className="btn btn-primary mt-5 btn-sm"
                  onClick={licenseImgClick}
                >
                  Upload Image
                </button>
              </div>
              <div className="col-6">
                <h2 className="text-dark fs-3 fw-bolder mb-5">
                  Authorized Signatory Copy
                </h2>
                <div className="register-document">
                  {signatoryImg ? (
                    <img
                      src={URL.createObjectURL(signatoryImg)}
                      alt="Signatory copy Img"
                      className="cursor-pointer document-img border border-2 border-secondary"
                    />
                  ) : (
                    <h4
                      onClick={signatoryImgClick}
                      className="cursor-pointer mb-0 document-img border border-2 border-secondary d-flex justify-content-center align-items-center"
                    >
                      No Image
                    </h4>
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*"
                  ref={signatoryImgRef}
                  onChange={signatoryImgChange}
                  className="inputImg"
                />
                <button
                  className="btn btn-primary mt-5 btn-sm"
                  onClick={signatoryImgClick}
                >
                  Upload Image
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BusinessProfile;

const BusinessRegisterDocumnet = () => {};
