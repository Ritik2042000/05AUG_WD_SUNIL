import { Button, Link } from "@mui/material";
import React, { useEffect, useState } from "react";
import SelectComponents from "../CommonLayouts/SelectComponents";
import PopoverComponent from "../CommonLayouts/PopoverComponent";


const Contract = () => {

    const contrctData = {
        General: {
            Used: [
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: '١- إتفاقية تأجير شقة',
                    date: '05/12/2023',
                    status: 'Rejected',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: '٢- إتفاقية عدم الإفصاح',
                    date: '05/12/2023',
                    status: 'Ready',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: '2 - Contract Status - Check - Contract - Lorem Ipsum is',
                    date: '05/12/2023',
                    status: 'Draft',
                    img1: '',
                    img2: '',

                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: 'Contract Status - Check - Contract',
                    date: '05/12/2023',
                    status: 'Review',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: 'Non-Disclosure and Confidentiality Agreement Between Tothiq - Creativ',
                    date: '05/12/2023',
                    status: 'Ready',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
                },
            ],
        },


        Invited: {
            Used: [
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: '١- إتفاقية تأجير شقة',
                    date: '05/12/2023',
                    status: 'Rejected',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: '٢- إتفاقية عدم الإفصاح',
                    date: '05/12/2023',
                    status: 'Ready',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: '2 - Contract Status - Check - Contract - Lorem Ipsum is',
                    date: '05/12/2023',
                    status: 'Draft',
                    img1: '',
                    img2: '',

                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: 'Contract Status - Check - Contract',
                    date: '05/12/2023',
                    status: 'Review',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

                },
                {
                    userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    title: 'Non-Disclosure and Confidentiality Agreement Between Tothiq - Creativ',
                    date: '05/12/2023',
                    status: 'Ready',
                    img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                    img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
                },
            ],

        },

        MyContarcts: {

        },



        Used: [
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: '١- إتفاقية تأجير شقة',
                date: '05/12/2023',
                status: 'Rejected',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

            },
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: '٢- إتفاقية عدم الإفصاح',
                date: '05/12/2023',
                status: 'Ready',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
            },
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: '2 - Contract Status - Check - Contract - Lorem Ipsum is',
                date: '05/12/2023',
                status: 'Draft',
                img1: '',
                img2: '',

            },
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: 'Contract Status - Check - Contract',
                date: '05/12/2023',
                status: 'Review',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

            },
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: 'Non-Disclosure and Confidentiality Agreement Between Tothiq - Creativ',
                date: '05/12/2023',
                status: 'Ready',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
            },
        ],
        Draft: [
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: '2 - Contract Status - Check - Contract - Lorem Ipsum is',
                date: '05/12/2023',
                status: 'Draft',
                img1: '',
                img2: '',

            },
        ],
        Review: [
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: 'Contract Status - Check - Contract',
                date: '05/12/2023',
                status: 'Review',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

            },
        ],
        Ready: [
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: '٢- إتفاقية عدم الإفصاح',
                date: '05/12/2023',
                status: 'Ready',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
            },
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: 'Non-Disclosure and Confidentiality Agreement Between Tothiq - Creativ',
                date: '05/12/2023',
                status: 'Ready',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',
            },
        ],
        Signed: [],
        Rejected: [
            {
                userImg: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                title: '١- إتفاقية تأجير شقة',
                date: '05/12/2023',
                status: 'Rejected',
                img1: 'http://panel.tothiq.com/media/tothiq_pic/images.jpeg',
                img2: 'http://panel.tothiq.com/media/tothiq_pic/20231128074221-63781-profile_picture_2023_11_28_19_12_21.jpeg',

            },
        ],
        Deleted: [],
        Cancelled: [],
    }

    const [searchData, setSearchData] = useState('');

    const selectData = [
        { value: 'Recently Updated', label: 'Recently Updated' },
        { value: 'Last Month', label: 'Last Month' },
        { value: 'Last Quarter', label: 'Last Quarter' },
        { value: 'Last Year', label: 'Last Year' }
    ]


    return (
        <>
            <div
                className="content d-flex flex-column flex-column-fluid pt-0"
                id="kt_content"
            >
                {/*begin::Post*/}
                <div className="post d-flex flex-column-fluid" id="kt_post">
                    {/*begin::Container*/}
                    <div id="kt_content_container" className="container-xxl mt-10">
                        {/*begin::Toolbar*/}
                        <div className="toolbar" id="kt_toolbar">
                            {/*begin::Container*/}
                            <div id="kt_toolbar_container" className="d-flex flex-stack">
                                {/*begin::Page title*/}
                                <div
                                    data-kt-swapper="true"
                                    data-kt-swapper-mode="prepend"
                                    data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                                    className="page-title d-flex align-items-center flex-wrap me-3 mb-5"
                                >
                                    {/*begin::Title*/}
                                    <h1 className="d-flex align-items-center text-dark fw-bolder fs-3 my-1">
                                        Contract
                                    </h1>
                                    {/*end::Title*/}
                                </div>
                                {/*end::Page title*/}
                            </div>
                            {/*end::Container*/}
                        </div>
                        {/*end::Toolbar*/}
                        <div className="d-flex flex-lg-wrap flex-wrap container justify-content-md-around ">
                            <div className="w-xxl-350px col-lg-3 col-md-4 col-12">
                                <div className="card mb-5 pb-5  w-100 ">
                                    <div className="card-body ps-md-3">
                                        <div className="new_folder p-4">
                                            <label type="button" class="text-primary fs-5" data-bs-toggle="modal" data-bs-target="#exampleModalCenter"> Add New Folder</label>

                                        </div>
                                        <div className="menu-link  myFolder d-flex align-items-baseline justify-content-between pe-2" id="myTab" role="tablist">
                                            <p className="fs-5 px-4 py-2 text-hover-primary pointer ">My Folders</p>
                                            <div className="icon">
                                                <i className="fas fa-chevron-right"></i>
                                            </div>

                                        </div>
                                        <div className="files ms-4 ps-xl-3">
                                            <p className="mb-0 fs-5 fw-bold text-hover-primary p-2 pointer nav " id="General-tab" data-bs-toggle="tab" data-bs-target="#General-tab-pane" type="button" role="tab" aria-controls="General-tab-pane" aria-selected="false">General</p>
                                            <p className="mb-0 fs-5 fw-bold text-hover-primary p-2 pointer" id="Invited-tab" data-bs-toggle="tab" data-bs-target="#Invited-tab-pane" type="button" role="tab" aria-controls="Invited-tab-pane" aria-selected="false">invited</p>
                                            <div className="d-flex align-items-center justify-content-between pe-2 flex-wrap">
                                                <p className="mb-0 fs-5 fw-bold text-hover-primary p-2 pointer">My Contarcts</p>
                                                <div className="contracts-icons">
                                                    <i className="fas fa-pencil-alt fs-3 text-hover-dark pe-2"></i>
                                                    <i className="fas fa-trash-alt fs-3 text-hover-dark ps-2"></i>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-xl-8 col-md-7 col-lg-8 col-12 flex-lg-row-fluid ms-lg card ms-md-4 me-4" >
                                <div className="mb-5 pb-5 card ">
                                    <div className="card-body">
                                        <ul className="nav nav-tabs nav-custom nav-tabs nav-line-tabs nav-line-tabs-2x border-0 fs-4 fw-bold row g-5 g-xxl-8 m-0  ps-0" id="myTab" role="tablist">
                                            <li className="nav-item card col-3 col-md-6 col-12 col-lg-3 ps-0" role="presentation">
                                                <div className="card-body nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0 active " id="Used-tab" data-bs-toggle="tab" data-bs-target="#Used-tab-pane" type="button" role="tab" aria-controls="Used-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark '>{contrctData.Used.length}</p>
                                                        <p className='text-dark'>Used</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="nav-item card col-3 col-md-6 col-12 col-lg-3 ps-0" role="presentation">
                                                <div className="nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0" id="Draft-tab" data-bs-toggle="tab" data-bs-target="#Draft-tab-pane" type="button" role="tab" aria-controls="Draft-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark'>{contrctData.Draft.length}</p>
                                                        <p className='text-dark'>Draft</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="nav-item card col-3 col-md-6 col-12 col-lg-3 ps-0" role="presentation">
                                                <div className="nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0" id="Review-tab" data-bs-toggle="tab" data-bs-target="#Review-tab-pane" type="button" role="tab" aria-controls="Review-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark'>{contrctData.Review.length}</p>
                                                        <p className='text-dark'>Review</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="nav-item card col-3 col-md-6 col-12 col-lg-3 ps-0" role="presentation">
                                                <div className="nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0" id="Ready-tab" data-bs-toggle="tab" data-bs-target="#Ready-tab-pane" type="button" role="tab" aria-controls="Ready-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark'>{contrctData.Ready.length}</p>
                                                        <p className='text-dark'>Ready</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="nav-item card col-3 col-md-6 col-12 col-lg-3  ps-0" role="presentation">
                                                <div className="nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0" id="Signed-tab" data-bs-toggle="tab" data-bs-target="#Signed-tab-pane" type="button" role="tab" aria-controls="Signed-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark'>{contrctData.Signed.length}</p>
                                                        <p className='text-dark'>Signed</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="nav-item card col-3 col-md-6 col-12 col-lg-3 ps-0" role="presentation">
                                                <div className="nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0" id="Rejected-tab" data-bs-toggle="tab" data-bs-target="#Rejected-tab-pane" type="button" role="tab" aria-controls="Rejected-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark'>{contrctData.Rejected.length}</p>
                                                        <p className='text-dark'>Rejected</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="nav-item card col-3 col-md-6 col-12 col-lg-3 ps-0" role="presentation">
                                                <div className="nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0" id="Deleted-tab" data-bs-toggle="tab" data-bs-target="#Deleted-tab-pane" type="button" role="tab" aria-controls="Deleted-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark'>{contrctData.Deleted.length}</p>
                                                        <p className='text-dark'>Deleted</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="nav-item card  col-md-6 col-12 col-lg-3 ps-0" role="presentation">
                                                <div className="nav-link text-active-primary card bg-secondary bg-opacity-25 mb-xl-0 ms-0" id="Cancelled-tab" data-bs-toggle="tab" data-bs-target="#Cancelled-tab-pane" type="button" role="tab" aria-controls="Cancelled-tab-pane" aria-selected="false">
                                                    <div className="ms-3 pt-2">
                                                        <p className='text-dark'>{contrctData.Cancelled.length}</p>
                                                        <p className='text-dark'>Cancelled</p>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>

                                        <div className="searchndselect my-5 d-flex justify-content-between flex-wrap ">
                                            <div className="col-7 mb-5 mb-lg-0 position-relative">
                                                <form data-kt-search-element="form" className=" d-lg-block w-100 mb-lg-0 position-relative" >
                                                    <span className="svg-icon svg-icon-2 svg-icon-gray-700 position-absolute top-50 translate-middle-y ms-4"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect><path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor">
                                                        </path>
                                                    </svg>
                                                    </span>
                                                    <input className="form-control form-control-solid h-40px bg-body ps-13 fs-7" type="text" id="filter" value={searchData} placeholder="Search Contact" onChange={(e) => setSearchData(e.target.value)} />
                                                </form>
                                            </div>
                                            <div className="select col-12 col-md-4 ">
                                                <SelectComponents Options={selectData} />
                                            </div>
                                        </div>

                                        <div className="tab-content" id="myTabContent" style={{ minHeight: '200px' }}>
                                            <div className="tab-pane fade active show" id="Used-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">
                                                {
                                                    contrctData && contrctData.Used.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                        return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                            <div className="row g-0">
                                                                <div className="col-md-3 col-lg-2  cont_block_1 d-flex justify-content-center align-items-center">
                                                                    <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                        <img
                                                                            src={data.userImg}
                                                                            alt=""
                                                                            className="rounded-circle"
                                                                            style={{
                                                                                width: "75px",
                                                                                height: "75px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                        />
                                                                    </span>
                                                                </div>
                                                                <div className="col-md-6 cont_block_2">
                                                                    <div className="card-body p-5">
                                                                        <div
                                                                            className="card-title fs-5 fw-bolder"
                                                                            style={{ cursor: "pointer" }}
                                                                        >
                                                                            {data.title}
                                                                        </div>
                                                                        <p className="card-text mb-0">
                                                                            Created Date : {data.date}
                                                                        </p>
                                                                        <div className="d-flex status flex-wrap">
                                                                            <p className="card-text mb-0">
                                                                                <small className="text-muted">
                                                                                    Status : {data.status}
                                                                                </small>
                                                                            </p>
                                                                            {data.status === 'Review' ?
                                                                                <Link className="card-text ms-lg-5" to="">
                                                                                    <small className="text-muted">
                                                                                        Add Appendix
                                                                                    </small>
                                                                                </Link> : ''}
                                                                            <Link
                                                                                className="card-text"
                                                                                to=""
                                                                            >
                                                                                <small className="text-muted ms-5">
                                                                                    Duplicate
                                                                                </small>
                                                                            </Link>
                                                                            <PopoverComponent />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3 col-lg-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                    {data.status === 'Draft' ? '' :
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <div className="ms-2">

                                                                                <img
                                                                                    src={data.img1}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />

                                                                            </div>
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img2}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>


                                                                        </span>
                                                                    }
                                                                </div>


                                                            </div>
                                                        </div>
                                                    })
                                                }

                                            </div>
                                            <div className="tab-pane fade" id="Draft-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">Draft
                                                {
                                                    contrctData && contrctData.Draft.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                        return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                            <div className="row g-0">
                                                                <div className="col-md-2 cont_block_1 d-flex justify-content-center align-items-center">
                                                                    <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                        <img
                                                                            src={data.userImg}
                                                                            alt=""
                                                                            className="rounded-circle"
                                                                            style={{
                                                                                width: "75px",
                                                                                height: "75px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                        />
                                                                    </span>
                                                                </div>
                                                                <div className="col-md-6 cont_block_2">
                                                                    <div className="card-body p-5">
                                                                        <div
                                                                            className="card-title fs-5 fw-bolder"
                                                                            style={{ cursor: "pointer" }}
                                                                        >
                                                                            {data.title}
                                                                        </div>
                                                                        <p className="card-text mb-0">
                                                                            Created Date : {data.date}
                                                                        </p>
                                                                        <div className="d-flex">
                                                                            <p className="card-text mb-0">
                                                                                <small className="text-muted">
                                                                                    Status : {data.status}
                                                                                </small>
                                                                            </p>
                                                                            <Link
                                                                                className="card-text"
                                                                                to="/user/contract-screen#."
                                                                            >
                                                                                <small className="text-muted ms-5">
                                                                                    Duplicate
                                                                                </small>
                                                                            </Link>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                    {data.status === 'Draft' ? '' :
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img1}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img2}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                        </span>
                                                                    }
                                                                </div>

                                                            </div>
                                                        </div>
                                                    })
                                                }
                                            </div>
                                            <div className="tab-pane fade" id="Review-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">
                                                {/* {
                                        contrctData.Review.length === 0 ? (
                                            <p className="mt-5 pt-5 fs-4 text-center">Currently, there is no record found in your contracts list!</p>
                                          ) : (
                                            contrctData.Review.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).length === 0 ? (
                                              <p className="mt-5 pt-5 fs-4 text-center">No matching records found for your search criteria!</p>
                                            ) : (
                                              contrctData.Review.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) 
                                    } */}

                                                {

                                                    contrctData.Review.length === 0 ? <p className="mt-5 pt-5 fs-4 text-center">Currently there is no record found in your contracts list!</p> : contrctData.Review.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).length === 0 ? <p className="mt-5 pt-5 fs-4 text-center">No matching records found for your search criteria!</p> :
                                                        contrctData.Review.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                            return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                                <div className="row g-0">
                                                                    <div className="col-md-2 cont_block_1 d-flex justify-content-center align-items-center">
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <img
                                                                                src={data.userImg}
                                                                                alt=""
                                                                                className="rounded-circle"
                                                                                style={{
                                                                                    width: "75px",
                                                                                    height: "75px",
                                                                                    cursor: "pointer",
                                                                                }}
                                                                            />
                                                                        </span>
                                                                    </div>
                                                                    <div className="col-md-6 cont_block_2">
                                                                        <div className="card-body p-5">
                                                                            <div
                                                                                className="card-title fs-5 fw-bolder"
                                                                                style={{ cursor: "pointer" }}
                                                                            >
                                                                                {data.title}
                                                                            </div>
                                                                            <p className="card-text mb-0">
                                                                                Created Date : {data.date}
                                                                            </p>
                                                                            <div className="d-flex">
                                                                                <p className="card-text mb-0">
                                                                                    <small className="text-muted">
                                                                                        Status : {data.status}
                                                                                    </small>
                                                                                </p>
                                                                                <Link
                                                                                    className="card-text"
                                                                                    to="/user/contract-screen#."
                                                                                >
                                                                                    <small className="text-muted ms-5">
                                                                                        Duplicate
                                                                                    </small>
                                                                                </Link>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="col-md-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                        {data.status === 'Draft' ? '' :
                                                                            <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                                <div className="ms-2">
                                                                                    <img
                                                                                        src={data.img1}
                                                                                        alt=""
                                                                                        className="rounded-circle"
                                                                                        style={{ width: "40px", height: "40px" }}
                                                                                    />
                                                                                </div>
                                                                                <div className="ms-2">
                                                                                    <img
                                                                                        src={data.img2}
                                                                                        alt=""
                                                                                        className="rounded-circle"
                                                                                        style={{ width: "40px", height: "40px" }}
                                                                                    />
                                                                                </div>
                                                                            </span>
                                                                        }
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        })
                                                }
                                            </div>
                                            <div className="tab-pane fade" id="Ready-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">Ready
                                                {
                                                    contrctData.Ready.length === 0 ? <p className="mt-5 pt-5 fs-4 text-center">Currently there is no record found in your contracts list!</p> : contrctData.Ready.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                        return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                            <div className="row g-0">
                                                                <div className="col-md-2 cont_block_1 d-flex justify-content-center align-items-center">
                                                                    <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                        <img
                                                                            src={data.userImg}
                                                                            alt=""
                                                                            className="rounded-circle"
                                                                            style={{
                                                                                width: "75px",
                                                                                height: "75px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                        />
                                                                    </span>
                                                                </div>
                                                                <div className="col-md-6 cont_block_2">
                                                                    <div className="card-body p-5">
                                                                        <div
                                                                            className="card-title fs-5 fw-bolder"
                                                                            style={{ cursor: "pointer" }}
                                                                        >
                                                                            {data.title}
                                                                        </div>
                                                                        <p className="card-text mb-0">
                                                                            Created Date : {data.date}
                                                                        </p>
                                                                        <div className="d-flex">
                                                                            <p className="card-text mb-0">
                                                                                <small className="text-muted">
                                                                                    Status : {data.status}
                                                                                </small>
                                                                            </p>
                                                                            <Link
                                                                                className="card-text"
                                                                                to=""
                                                                            >
                                                                                <small className="text-muted ms-5">
                                                                                    Duplicate
                                                                                </small>
                                                                            </Link>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                    {data.status === 'Draft' ? '' :
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img1}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img2}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                        </span>
                                                                    }
                                                                </div>

                                                            </div>
                                                        </div>
                                                    })
                                                }
                                            </div>
                                            <div className="tab-pane fade" id="Signed-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">
                                                {
                                                    contrctData.Signed.length === 0 ? <p className="mt-5 pt-5 fs-4 text-center">Currently there is no record found in your contracts list!</p> : contrctData.Signed.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                        return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                            <div className="row g-0">
                                                                <div className="col-md-2 cont_block_1 d-flex justify-content-center align-items-center">
                                                                    <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                        <img
                                                                            src={data.userImg}
                                                                            alt=""
                                                                            className="rounded-circle"
                                                                            style={{
                                                                                width: "75px",
                                                                                height: "75px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                        />
                                                                    </span>
                                                                </div>
                                                                <div className="col-md-6 cont_block_2">
                                                                    <div className="card-body p-5">
                                                                        <div
                                                                            className="card-title fs-5 fw-bolder"
                                                                            style={{ cursor: "pointer" }}
                                                                        >
                                                                            {data.title}
                                                                        </div>
                                                                        <p className="card-text mb-0">
                                                                            Created Date : {data.date}
                                                                        </p>
                                                                        <div className="d-flex">
                                                                            <p className="card-text mb-0">
                                                                                <small className="text-muted">
                                                                                    Status : {data.status}
                                                                                </small>
                                                                            </p>
                                                                            <Link
                                                                                className="card-text"
                                                                                to=""
                                                                            >
                                                                                <small className="text-muted ms-5">
                                                                                    Duplicate
                                                                                </small>
                                                                            </Link>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                    {data.status === 'Draft' ? '' :
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img1}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img2}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                        </span>
                                                                    }
                                                                </div>

                                                            </div>
                                                        </div>
                                                    })
                                                }
                                            </div>
                                            <div className="tab-pane fade" id="Rejected-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">Rejected
                                                {
                                                    contrctData.Rejected.length === 0 ? <p className="mt-5 pt-5 fs-4 text-center">Currently there is no record found in your contracts list!</p> : contrctData.Rejected.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                        return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                            <div className="row g-0">
                                                                <div className="col-md-2 cont_block_1 d-flex justify-content-center align-items-center">
                                                                    <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                        <img
                                                                            src={data.userImg}
                                                                            alt=""
                                                                            className="rounded-circle"
                                                                            style={{
                                                                                width: "75px",
                                                                                height: "75px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                        />
                                                                    </span>
                                                                </div>
                                                                <div className="col-md-6 cont_block_2">
                                                                    <div className="card-body p-5">
                                                                        <div
                                                                            className="card-title fs-5 fw-bolder"
                                                                            style={{ cursor: "pointer" }}
                                                                        >
                                                                            {data.title}
                                                                        </div>
                                                                        <p className="card-text mb-0">
                                                                            Created Date : {data.date}
                                                                        </p>
                                                                        <div className="d-flex">
                                                                            <p className="card-text mb-0">
                                                                                <small className="text-muted">
                                                                                    Status : {data.status}
                                                                                </small>
                                                                            </p>
                                                                            <Link
                                                                                className="card-text"
                                                                                to=""
                                                                            >
                                                                                <small className="text-muted ms-5">
                                                                                    Duplicate
                                                                                </small>
                                                                            </Link>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                    {data.status === 'Draft' ? '' :
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img1}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img2}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                        </span>
                                                                    }
                                                                </div>

                                                            </div>
                                                        </div>
                                                    })
                                                }
                                            </div>
                                            <div className="tab-pane fade" id="Deleted-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">
                                                {
                                                    contrctData.Deleted.length === 0 ? <p className="mt-5 pt-5 fs-4 text-center">Currently there is no record found in your contracts list!</p> : contrctData.Deleted.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                        return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                            <div className="row g-0">
                                                                <div className="col-md-2 cont_block_1 d-flex justify-content-center align-items-center">
                                                                    <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                        <img
                                                                            src={data.userImg}
                                                                            alt=""
                                                                            className="rounded-circle"
                                                                            style={{
                                                                                width: "75px",
                                                                                height: "75px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                        />
                                                                    </span>
                                                                </div>
                                                                <div className="col-md-6 cont_block_2">
                                                                    <div className="card-body p-5">
                                                                        <div
                                                                            className="card-title fs-5 fw-bolder"
                                                                            style={{ cursor: "pointer" }}
                                                                        >
                                                                            {data.title}
                                                                        </div>
                                                                        <p className="card-text mb-0">
                                                                            Created Date : {data.date}
                                                                        </p>
                                                                        <div className="d-flex">
                                                                            <p className="card-text mb-0">
                                                                                <small className="text-muted">
                                                                                    Status : {data.status}
                                                                                </small>
                                                                            </p>
                                                                            <Link
                                                                                className="card-text"
                                                                                to="/user/contract-screen#."
                                                                            >
                                                                                <small className="text-muted ms-5">
                                                                                    Duplicate
                                                                                </small>
                                                                            </Link>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                    {data.status === 'Draft' ? '' :
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img1}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img2}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                        </span>
                                                                    }
                                                                </div>

                                                            </div>
                                                        </div>
                                                    })
                                                }
                                            </div>
                                            <div className="tab-pane fade" id="Cancelled-tab-pane" role="tabpanel" aria-labelledby="" tabindex="0">
                                                {
                                                    contrctData.Cancelled.length === 0 ? <p className="mt-5 pt-5 fs-4 text-center">Currently there is no record found in your contracts list!</p> : contrctData.Cancelled.filter((data) => data.title.toLowerCase().includes(searchData.toLowerCase())).map((data, id) => {
                                                        return <div className="card mb-4 me-4 border-secondary border border-2" key={id}>
                                                            <div className="row g-0">
                                                                <div className="col-md-2 cont_block_1 d-flex justify-content-center align-items-center">
                                                                    <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                        <img
                                                                            src={data.userImg}
                                                                            alt=""
                                                                            className="rounded-circle"
                                                                            style={{
                                                                                width: "75px",
                                                                                height: "75px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                        />
                                                                    </span>
                                                                </div>
                                                                <div className="col-md-6 cont_block_2">
                                                                    <div className="card-body p-5">
                                                                        <div
                                                                            className="card-title fs-5 fw-bolder"
                                                                            style={{ cursor: "pointer" }}
                                                                        >
                                                                            {data.title}
                                                                        </div>
                                                                        <p className="card-text mb-0">
                                                                            Created Date : {data.date}
                                                                        </p>
                                                                        <div className="d-flex">
                                                                            <p className="card-text mb-0">
                                                                                <small className="text-muted">
                                                                                    Status : {data.status}
                                                                                </small>
                                                                            </p>
                                                                            <Link
                                                                                className="card-text"
                                                                                to="/user/contract-screen#."
                                                                            >
                                                                                <small className="text-muted ms-5">
                                                                                    Duplicate
                                                                                </small>
                                                                            </Link>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-4 Authenticate_user-bg d-flex align-items-center justify-content-center">
                                                                    {data.status === 'Draft' ? '' :
                                                                        <span className="svg-icon svg-icon-2 d-flex align-items-center">
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img1}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                            <div className="ms-2">
                                                                                <img
                                                                                    src={data.img2}
                                                                                    alt=""
                                                                                    className="rounded-circle"
                                                                                    style={{ width: "40px", height: "40px" }}
                                                                                />
                                                                            </div>
                                                                        </span>
                                                                    }
                                                                </div>

                                                            </div>
                                                        </div>
                                                    })
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                    {/*end::Container*/}
                </div>
                {/*end::Post*/}
            </div>

            {/* my code  */}

            {/* offCanvas Code */}
            <div class="modal fade " id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" >
                    <div className="modal-content">
                        <div className="modal-body">
                            <div className="modal-header">
                                <div className="d-flex align-items-center justify-content-between">
                                    <h2>Create Folder</h2>
                                </div>
                                <button type="button" className="btn-close" aria-label="Close" data-bs-dismiss="modal">
                                </button>
                            </div>
                            <div className="py-lg-10 px-lg-10">
                                <div className="mb-8">
                                    <div span="12" className="col">
                                        <label className="fs-6 fw-bolder text-dark required form-label">Folder Name</label>
                                        <input name="folder_name" type="text" pattern="" minlength="" maxlength="" className="form-control" />
                                    </div>
                                </div>
                                <div className="mb-8 text-end">
                                    <div span="12" className="col">
                                        <label className="fs-6 fw-bolder text-dark required form-label">إسم الملف</label>
                                        <input name="folder_name_arabic" type="text" pattern="" minlength="" maxlength="" className="form-control text-end" />
                                    </div>
                                </div>
                                <div className="mb-10 parent_folder">
                                    <label className="fs-6 fw-bolder text-dark  form-label">Parent Folder</label>
                                    <SelectComponents />
                                </div>
                                <div className="d-flex justify-content-end">
                                    <button className="btn btn-sm btn-primary" type="button">Create Folder</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



        </>
    );
};

export default Contract;


