import React from 'react';

const Dashboard = () => {
  return (
    <div>
      <div className="content d-flex flex-column flex-column-fluid pt-0" id="kt_content">
        {/*begin::Post*/}
        <div className="post d-flex flex-column-fluid" id="kt_post">
          {/*begin::Container*/}
          <div id="kt_content_container" className="container-xxl mt-10">
            {/*begin::Toolbar*/}
            <div className="toolbar" id="kt_toolbar">
              {/*begin::Container*/}
              <div
                id="kt_toolbar_container"
                className="d-flex flex-stack"
              >
                {/*begin::Page title*/}
                <div
                  data-kt-swapper="true"
                  data-kt-swapper-mode="prepend"
                  data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                  className="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                >
                  {/*begin::Title*/}
                  <h1 className="d-flex align-items-center text-dark fw-bolder fs-3 my-1">
                    Home
                  </h1>
                  {/*end::Title*/}
                </div>
                {/*end::Page title*/}
              </div>
              {/*end::Container*/}
            </div>
            {/*end::Toolbar*/}
            <div className='dashboard_otr'>
              {/*begin::Row*/}
              <div className='row'>
                <div className='col-xxl-6'>
                  <div className="card shadow-sm">
                    <div className="card-header">
                      <h3 className="card-title">Contracts Summary</h3>
                    </div>
                    <div className='card-body'>
                      <div className='row'>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>8140</h3>
                              <p>Used Contracts</p>
                            </div>
                          </div>
                        </div>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>8140</h3>
                              <p>Draft Contracts</p>
                            </div>
                          </div>
                        </div>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>140</h3>
                              <p>Under - Review</p>
                            </div>
                          </div>
                        </div>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>1340</h3>
                              <p>Waiting for Sign</p>
                            </div>
                          </div>
                        </div>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>2233</h3>
                              <p>Ready for Sign</p>
                            </div>
                          </div>
                        </div>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>4312</h3>
                              <p>Delete Contracts</p>
                            </div>
                          </div>
                        </div>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>108</h3>
                              <p>Cancelled Contracts</p>
                            </div>
                          </div>
                        </div>
                        <div className='col-xxl-3'>
                          <div className='card bg-secondary bg-opacity-25'>
                            <div className='card-body'>
                              <h3>09</h3>
                              <p>Rejected Contracts</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className='col-xxl-6'></div>
              </div>
              {/*end::Row*/}
            </div>
          </div>
          {/*end::Container*/}
        </div>
        {/*end::Post*/}
      </div>

    </div>
  )
}

export default Dashboard